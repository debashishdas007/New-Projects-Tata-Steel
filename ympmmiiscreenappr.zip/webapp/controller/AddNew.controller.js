/*sap.m.Input.extend('InputChanged', {
  renderer: {},
  onAfterRendering: function() {
    if (sap.m.Input.prototype.onAfterRendering) {
      sap.m.Input.prototype.onAfterRendering.apply(this, arguments);
    }
    this.$().find('INPUT').keypress(function() {
       if(event.keyCode === 13) {
         this.fireChange({});
       }
    }.bind(this));
  }
});*/

sap.ui.define([
	"com/expressionapprappr/controller/Master.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Master, JSONModel, History, MessageToast, Filter, FilterOperator) {
	"use strict";

	return Master.extend("com.expressionappr.controller.AddNew", {

		onInit: function () {
			this.getRouter().getRoute("second").attachPatternMatched(this._onObjectMatched, this);
			var oView = this.getView();
			oView.setModel(new JSONModel({
				multiplier: "MINS"
			}), "ui");

		},
		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			var oAddNewEntity = {
				"PLANT": (oEvent.getParameter("arguments").plant === "null" ? "" : oEvent.getParameter("arguments").plant),
				"PLANT_SEC": (oEvent.getParameter("arguments").plantSection === "null" ? "" : oEvent.getParameter("arguments").plantSection),
				"PLANT_LOC": (oEvent.getParameter("arguments").plantLocation === "null" ? "" : oEvent.getParameter("arguments").plantLocation),
				"FUNC_LOC": (oEvent.getParameter("arguments").functionLocation === "null" ? "" : oEvent.getParameter(
					"arguments").functionLocation),
				"PLANNER_GRP": (oEvent.getParameter("arguments").plannerGrp === "null" ? "" : oEvent.getParameter("arguments").plannerGrp),
				"EQUIPMENT": (oEvent.getParameter("arguments").equipment === "null" ? "" : oEvent.getParameter("arguments").equipment),
				"EQUIPMENT_DESC": (oEvent.getParameter("arguments").equipmentDesc === "null" ? "" : oEvent.getParameter("arguments").equipmentDesc),
				//"TAG_FILTER": "S1_DRV",
				"ACTIVE": true,
				"GARBAGE_VAL": "",
				"GARBAGE_CODE": "",
				"MEASUREMENT_TYPE": "",
				"FREQUENCY": "",
				"DATASOURCE": "" //DATASOURCE
			};

			this.getView().setModel(new JSONModel(oAddNewEntity), "EntityAddModel");
		},

		inputValidation: function (oExpressionEntity, frequency) {
			var oModel = this.getModel(),
				that = this,
				InputFilter = new Filter({
					filters: [
						new Filter("PLANT", FilterOperator.EQ, oExpressionEntity.PLANT),
						new Filter("PLANT_LOC", FilterOperator.EQ, oExpressionEntity.PLANT_LOC),
						new Filter("PLANT_SEC", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
						new Filter("PLANNER_GRP", FilterOperator.EQ, oExpressionEntity.PLANNER_GRP),
						new Filter("FUNC_LOC", FilterOperator.EQ, oExpressionEntity.FUNC_LOC),
						new Filter("EQUIPMENT", FilterOperator.EQ, oExpressionEntity.EQUIPMENT),
					],
					and: true
				});
			oModel.read("/ET_VALIDATESet", {
				filters: [InputFilter],
				"async": false,
				success: function (oData, response) {
					if (oData && oData.results && oData.results[0]) {
						if (oData.results[0].VALID && oData.results[0].VALID === "F") {
							sap.m.MessageBox.error(oData.results[0].ERR_MSG);
						} else if (oData.results[0].VALID && oData.results[0].VALID === "S") {
							var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
							oRouter.navTo("fourth", {
								plant: oExpressionEntity.PLANT,
								plantSection: oExpressionEntity.PLANT_SEC,
								plantLocation: oExpressionEntity.PLANT_LOC,
								functionLocation: oExpressionEntity.FUNC_LOC,
								plannerGrp: oExpressionEntity.PLANNER_GRP,
								equipment: oExpressionEntity.EQUIPMENT,
								server: oExpressionEntity.DATASOURCE,
								equipmentDesc: oData.results[0].EQUIP_DESC,
								garbageCode: oExpressionEntity.GARBAGE_CODE,
								garbageVal: oExpressionEntity.GARBAGE_VAL,
								measurementType: oExpressionEntity.MEASUREMENT_TYPE,
								frequency: frequency,
								active: oExpressionEntity.ACTIVE
							});
						} else {
							sap.m.MessageBox.error("Server returned incorrect response");
						}
					} else {
						sap.m.MessageBox.error("Server returned incorrect response");
					}

				},
				error: function (oError) {
					//error handling
				}
			});
			oModel.attachRequestSent(function () {
				that.byId("pageAdd").setBusy(true);
			});
			oModel.attachRequestCompleted(function () {
				that.byId("pageAdd").setBusy(false);
			});
		},
		onFetchTagsBtnPress: function () {

			var //oModel = this.getModel(),
				oDataModel = this.getModel("EntityAddModel");
			var oData = oDataModel.getData(),
				//that = this,
				valid = false;

			var garbagecode = this.byId("garbageThresholdCodeSelectedId").getSelectedItem() === null ? "" : this.byId(
				"garbageThresholdCodeSelectedId").getSelectedItem().getKey();
			oDataModel.setProperty("/GARBAGE_CODE", garbagecode);

			var garbageVal = this.byId("garbageThresholdCodeSelectedId").getSelectedItem() === null ? "" : this.byId(
				"garbageThresholdCodeSelectedId").getSelectedItem().getAdditionalText();
			//oDataModel.setProperty("GARBAGE_VAL", garbageVal);
			garbageVal = garbageVal !== null || garbageVal !== "" ? garbageVal : "";
			oData.GARBAGE_VAL = garbageVal;

			var measurementType = this.byId("measurementTypeSelectedId").getSelectedItem() === null ? "" : this.byId(
				"measurementTypeSelectedId").getSelectedItem().getKey();
			oDataModel.setProperty("/MEASUREMENT_TYPE", measurementType);

			var server = this.byId("dataSourceSelectedId").getSelectedItem() === null ? "" : this.byId("dataSourceSelectedId").getSelectedItem()
				.getKey();
			//oDataModel.setProperty("SERVER", server);
			oData.DATASOURCE = server;

			//convert frequency

			/*var frequency = this.byId("frequencySelectedId").getSelectedItem() === null ? "" : this.byId("frequencySelectedId").getSelectedItem()
				.getKey();
			oDataModel.setProperty("/FREQUENCY", frequency);*/

			//oData.EQUIPMENT_DESC = null;
			//testing: start
			oData.EQUIPMENT_DESC = this.getModel("globalModel").getProperty("/equipmentdesc");
			for (var property in oData) {
				if (oData[property] !== "") {
					valid = true;
				} else {
					valid = false;
					break;
				}
			}

			/*for (var property in oData) {
				if (oData[property] !== "") {
					valid = true;
				} else {
					oData[property] = "null";
				}
			}
			valid = true;*/
			//testing : end
			if (valid) {
				this.inputValidation(oData, this.convertFrequency(oData, this.byId("frequencyMultiplierSelectedId")));
			} else {
				sap.m.MessageBox.error("Please fill all mandatory* fields");
			}
		}
	});

});