var _oFilters = null;
sap.ui.define([
	"com/expressionappr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	'sap/m/ColumnListItem',
	'sap/m/Label',
	'sap/m/Token',
	'sap/ui/model/type/String',
	'sap/m/SearchField',
	"sap/ui/core/routing/History",
	"com/expressionappr/model/formatter"
], function (BaseController, JSONModel, MessageToast, MessageBox, Filter, FilterOperator, Fragment, ColumnListItem, Label, Token,
	typeString,
	SearchField, History, formatter) {
	"use strict";

	return BaseController.extend("com.expressionappr.controller.Master", {

		formatter: formatter,
		onInit: function () {
			var oView = this.getView();
			_oFilters = null;
			oView.setModel(new JSONModel({
				globalFilter: "",
				availabilityFilterOn: false,
				cellFilterOn: false,
				filterBarVisibiltyOn: true,
				approvalsPressedOn: true
			}), "ui");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;

			this._operation = "";
			this._plantInput = this.byId("plantId");
			this._plantSectionInput = this.byId("plantSectionId");
			this._plantLocationInput = this.byId("plantLocationId");
			this._functionLocationInput = this.byId("functionLocationId");
			this._plannerGroupInput = this.byId("plannerGroupId");
			this._equipmentInput = this.byId("equipmentId");
			this._measurePointInput = this.byId("measurePointId");
		},

		//UI TABLE FILTERS and misc ----------------------------------
		_filter: function () {
			var oFilter = null;
			if (this._oGlobalFilter && this._oPriceFilter) {
				oFilter = new sap.ui.model.Filter([this._oGlobalFilter, this._oPriceFilter], true);
			} else if (this._oGlobalFilter) {
				oFilter = this._oGlobalFilter;
			} else if (this._oPriceFilter) {
				oFilter = this._oPriceFilter;
			}

			this.getView().byId("table").getBinding("rows").filter(oFilter, "Application");
		},
		filterGlobally: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			this._oGlobalFilter = null;

			if (sQuery) {
				this._oGlobalFilter = new Filter([
					new Filter("Name", FilterOperator.Contains, sQuery),
					new Filter("Category", FilterOperator.Contains, sQuery)
				], false);
			}

			this._filter();
		},
		clearAllFilters: function (oEvent) {

			this._plantInput.setValue("");
			this._plantSectionInput.setValue("");
			this._plantLocationInput.setValue("");
			this._functionLocationInput.setValue("");
			this._plannerGroupInput.setValue("");
			this._equipmentInput.setValue("");
			this._measurePointInput.setValue("");
			_oFilters = null;
			this.getView().getModel("ui").setProperty("/filterBarVisibiltyOn", false);
			this.filterBarVisibiltyOn();
			/*var oTable = this.getView().byId("table");

			var oUiModel = this.getView().getModel("ui");
			oUiModel.setProperty("/globalFilter", "");
			oUiModel.setProperty("/availabilityFilterOn", false);

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._filter();

			var aColumns = oTable.getColumns();
			for (var i = 0; i < aColumns.length; i++) {
				oTable.filter(aColumns[i], null);
			}*/
		},

		//Btn Press events -------------------------------------------
		approvalsPressedOn: function () {
			var oUiModel = this.getView().getModel("ui");
			var state = !!oUiModel.getProperty("/approvalsPressedOn");
			var approvalbtnbtn = this.byId("approvalbtn");
			//hide the delete button on approval screen
			//unhide the approve and reject buttons
			var oTable = this.byId("expressionsTable1");
			if (state) {
				oUiModel.setProperty("/approvalsPressedOn", true);
				this.byId("expressionsTable1").setNoDataText("No Expression for approval.");
				approvalbtnbtn.setPressed(true);
				//fetch approvals and bind to table
				oTable.bindItems({
					path: "/ET_DETAILSSet",
					template: oTable.getBindingInfo("items").template,
					filters: null
				});
				oTable.setMode("MultiSelect");
				this.byId("approveAllBtn1").setVisible(true);
			} else {
				this.byId("expressionsTable1").setNoDataText("No Expressions found. Choose one or more filters to load data.");
				oUiModel.setProperty("/approvalsPressedOn", false);
				approvalbtnbtn.setPressed(false);
				oTable.removeAllItems();
				if (_oFilters && _oFilters.aFilters && _oFilters.aFilters.length >= 1) {
					oTable.bindItems({
						path: "/ET_DETAILSSet",
						template: oTable.getBindingInfo("items").template,
						filters: _oFilters
					});
					oTable.setMode("SingleSelectMaster");
				}
				this.byId("approveAllBtn1").setVisible(false);
			}
		},
		filterBarVisibiltyOn: function () {
			var filterbarCtrl = this.byId("filterbar");
			var oUiModel = this.getView().getModel("ui");
			var filterbtn = this.byId("filterBtn");
			var state = !!oUiModel.getProperty("/filterBarVisibiltyOn");
			if (state) {
				oUiModel.setProperty("/filterBarVisibiltyOn", true);
				filterbarCtrl.setVisible(true);
				filterbtn.setText("Hide Filter Bar");
			} else {
				oUiModel.setProperty("/filterBarVisibiltyOn", false);
				filterbarCtrl.setVisible(false);
				filterbtn.setText("Show Filter Bar");
			}
		},
		onSearchFilterPressed: function () {
			//fetch the values for the search field and bind to the table
			//unhide the delete button.. decide the state of the button based on a ui/model flag searchPressed and status pending
			//or should write smart expression in xml for the buttons?
			this.validateBeforeSearch();
			//set approvals in ui to false and call UI
			this.getView().getModel("ui").setProperty("/approvalsPressedOn", false);
			this.approvalsPressedOn();

		},
		validateBeforeSearch: function () {
			if (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1) {
				_oFilters = new Filter([], true);
			}
			if (_oFilters && _oFilters.aFilters //&& _oFilters.aFilters.length >= 1
			) {
				var oFilter = null;
				if (this.contains(_oFilters.aFilters, "sPath", "PLANT")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "PLANT").oValue1;
					if (this._plantInput.getValue() === "" || this._plantInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT");
					} else if (this._plantInput.getValue() != oFilter && !this._plantInput.getValue().startsWith(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT");
						_oFilters.aFilters.push(new Filter("PLANT", FilterOperator.EQ, this._plantInput.getValue()));
					}
				} else if ((this._plantInput.getValue() != "" && this._plantInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("PLANT", FilterOperator.EQ, this._plantInput.getValue()));
				}
				if (this.contains(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC").oValue1;
					if (this._plantSectionInput.getValue() === "" || this._plantSectionInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT_SEC");
					} else if (this._plantSectionInput.getValue() != oFilter && !this._plantSectionInput.getValue().startsWith(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT_SEC");
						_oFilters.aFilters.push(new Filter("PLANT_SEC", FilterOperator.EQ, this._plantSectionInput.getValue()));
					}
				} else if ((this._plantSectionInput.getValue() != "" && this._plantSectionInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("PLANT_SEC", FilterOperator.EQ, this._plantSectionInput.getValue()));
				}
				if (this.contains(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC").oValue1;
					if (this._plantLocationInput.getValue() === "" || this._plantLocationInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT_LOC");
					} else if (this._plantLocationInput.getValue() != oFilter && !this._plantLocationInput.getValue().startsWith(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT_LOC");
						_oFilters.aFilters.push(new Filter("PLANT_LOC", FilterOperator.EQ, this._plantLocationInput.getValue()));
					}
				} else if ((this._plantLocationInput.getValue() != "" && this._plantLocationInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("PLANT_LOC", FilterOperator.EQ, this._plantLocationInput.getValue()));
				}
				if (this.contains(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC").oValue1;
					if (this._functionLocationInput.getValue() === "" || this._functionLocationInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "FUNC_LOC");
					} else if (this._functionLocationInput.getValue() != oFilter && !this._functionLocationInput.getValue().startsWith(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "FUNC_LOC");
						_oFilters.aFilters.push(new Filter("FUNC_LOC", FilterOperator.EQ, this._functionLocationInput.getValue()));
					}
				} else if ((this._functionLocationInput.getValue() != "" && this._functionLocationInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("FUNC_LOC", FilterOperator.EQ, this._functionLocationInput.getValue()));
				}
				if (this.contains(_oFilters.aFilters, "sPath", "PLANNER_GRP")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP").oValue1;
					if (this._plannerGroupInput.getValue() === "" || this._plannerGroupInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANNER_GRP");
					} else if (this._plannerGroupInput.getValue() != oFilter && !this._plannerGroupInput.getValue().startsWith(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANNER_GRP");
						_oFilters.aFilters.push(new Filter("PLANNER_GRP", FilterOperator.EQ, this._plannerGroupInput.getValue()));
					}
				} else if ((this._plannerGroupInput.getValue() != "" && this._plannerGroupInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("PLANNER_GRP", FilterOperator.EQ, this._plannerGroupInput.getValue()));
				}
				if (this.contains(_oFilters.aFilters, "sPath", "EQUIPMENT")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "EQUIPMENT").oValue1;
					if (this._equipmentInput.getValue() === "" || this._equipmentInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "EQUIPMENT");
					} else if (this._equipmentInput.getValue() != oFilter && !this._equipmentInput.getValue().includes(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "EQUIPMENT");
						_oFilters.aFilters.push(new Filter("EQUIPMENT", FilterOperator.EQ, this._equipmentInput.getValue()));
					}
				} else if ((this._equipmentInput.getValue() != "" && this._equipmentInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("EQUIPMENT", FilterOperator.EQ, this._equipmentInput.getValue()));
				}
				if (this.contains(_oFilters.aFilters, "sPath", "MEASUR_POINT")) {
					oFilter = this.containsObject(_oFilters.aFilters, "sPath", "MEASUR_POINT").oValue1;
					if (this._measurePointInput.getValue() === "" || this._measurePointInput.getValue().trim() === "") {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "MEASUR_POINT");
					} else if (this._measurePointInput.getValue() != oFilter && !this._measurePointInput.getValue().includes(oFilter)) {
						_oFilters.aFilters = this.filterData(_oFilters.aFilters, "MEASUR_POINT");
						_oFilters.aFilters.push(new Filter("MEASUR_POINT", FilterOperator.EQ, this._measurePointInput.getValue()));
					}
				} else if ((this._measurePointInput.getValue() != "" && this._measurePointInput.getValue().trim() != "")) {
					_oFilters.aFilters.push(new Filter("MEASUR_POINT", FilterOperator.EQ, this._measurePointInput.getValue()));
				}
				//}
			}
		},
		onAddNewBtnPressNav: function (oEvent) {
			var plant = "null",
				plantLocation = "null",
				plantSection = "null",
				functionLocation = "null",
				plannerGrp = "null",
				equipment = "null",
				temp = null;
			if (_oFilters && _oFilters.aFilters && _oFilters.aFilters.length >= 1) {
				if (this.contains(_oFilters.aFilters, "sPath", "PLANT")) {
					temp = this.containsObject(_oFilters.aFilters, "sPath", "PLANT").oValue1;
					plant = Array.isArray(temp) ? temp[0] : temp;
				}
				if (this.contains(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
					temp = this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC").oValue1;
					plantSection = Array.isArray(temp) ? temp[0] : temp;
				}
				if (this.contains(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
					temp = this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC").oValue1;
					plantLocation = Array.isArray(temp) ? temp[0] : temp;
				}
				if (this.contains(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
					temp = this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC").oValue1;
					functionLocation = Array.isArray(temp) ? temp[0] : temp;
				}
				if (this.contains(_oFilters.aFilters, "sPath", "PLANNER_GRP")) {
					temp = this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP").oValue1;
					plannerGrp = Array.isArray(temp) ? temp[0] : temp;
				}
				if (this.contains(_oFilters.aFilters, "sPath", "EQUIPMENT")) {
					temp = this.containsObject(_oFilters.aFilters, "sPath", "EQUIPMENT").oValue1;
					equipment = Array.isArray(temp) ? temp[0] : temp;
				}
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("second", {
				plant: plant,
				plantSection: plantSection,
				plantLocation: plantLocation,
				functionLocation: functionLocation,
				plannerGrp: plannerGrp,
				equipment: equipment,
				equipmentDesc: this.getModel("globalModel").getProperty("/equipmentdesc")
			});
		},
		onAddBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteMaster");
		},
		ondiscardAddNewBtnPress: function () {
			this.onAddBack();
		},
		onEditBtnPress: function (oEvent) {
			//hide the draft button if the expression state is not new	
			this.getRouter().navTo("third", {
				objectId: oEvent.getSource().getParent().getBindingContext().getProperty("EXPRESSION_ID")
					//objectId: oEvent.getSource().getParent().getBindingContext().getPath()
			});
		},
		onApproveMultiBtnPress: function (oEvent) {
			var oTable = this.byId("expressionsTable1"),
				that = this,
				oContexts = oTable.getSelectedContexts();
			if (oContexts && oContexts.length) {
				sap.ui.core.BusyIndicator.show(5);
				if (!this.oApproveAllDialog) {
					//var path = oEvent.getSource().getBindingContext().getPath();
					this.oApproveAllDialog = sap.ui.xmlfragment(
						this.getView().getId(),
						"com.expressionappr.fragment.ApproveAll",
						this
					);
					this.getView().addDependent(this.oApproveAllDialog);

				}
				this.oApproveAllDialog.bindElement({
					path: oContexts[0].sPath
				});
				this.oApproveAllDialog.open();
				sap.ui.core.BusyIndicator.hide();

			} else {
				MessageBox.error("Please select atleast one checkbox of the expressions table");
				return;
			}
		},
		onApproveBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(5);
			if (!this.oApproveDialog) {
				this.oApproveDialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.expressionappr.fragment.Approve",
					this
				);
				this.getView().addDependent(this.oApproveDialog);
			}
			this.oApproveDialog.bindElement({
				path: oEvent.getSource().getBindingContext().getPath()
			});
			this.oApproveDialog.open();
			sap.ui.core.BusyIndicator.hide();
		},
		onReturnBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(5);
			if (!this.oReturnDialog) {
				this.oReturnDialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.expressionappr.fragment.Return",
					this
				);
				this.getView().addDependent(this.oReturnDialog);

			}
			this.oReturnDialog.bindElement({
				path: oEvent.getSource().getBindingContext().getPath()
			});
			this.oReturnDialog.open();
			sap.ui.core.BusyIndicator.hide();
		},
		onDeleteBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(5);
			if (!this.oDeleteDialog) {
				this.oDeleteDialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.expressionappr.fragment.Delete",
					this
				);

			}
			this.getView().addDependent(this.oDeleteDialog);
			this.oDeleteDialog.bindElement({
				path: oEvent.getSource().getBindingContext().getPath()
			});
			this.oDeleteDialog.open();
			sap.ui.core.BusyIndicator.hide();
		},
		onHistoryBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(5);
			if (!this.oHistoryDialog) {
				this.oHistoryDialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.expressionappr.fragment.History",
					this
				);
				this.getView().addDependent(this.oHistoryDialog);

			}
			this.oHistoryDialog.bindElement({
				path: oEvent.getSource().getBindingContext().getPath()
			});
			var oCmtBinding = this.byId("cmtlist").getBinding("items");
			oCmtBinding.filter([new sap.ui.model.Filter({
				path: "EXPRESSION_ID",
				operator: "EQ",
				value1: oEvent.getSource().getBindingContext().getProperty("EXPRESSION_ID")
			})]);
			this.oHistoryDialog.open();
			sap.ui.core.BusyIndicator.hide();
		},
		onViewBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(5);
			if (!this.oViewDialog) {
				this.oViewDialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.expressionappr.fragment.View",
					this
				);
				this.getView().addDependent(this.oViewDialog);

			}
			this.oViewDialog.bindElement({
				path: oEvent.getSource().getBindingContext().getPath()
			});
			var oCmtBinding = this.byId("cmtlist2").getBinding("items");
			oCmtBinding.filter([new sap.ui.model.Filter({
				path: "EXPRESSION_ID",
				operator: "EQ",
				value1: oEvent.getSource().getBindingContext().getProperty("EXPRESSION_ID")
			})]);
			this.oViewDialog.open();
			sap.ui.core.BusyIndicator.hide();
		},
		handleApproveDialogConfirm: function (oEvent) {
			if (this.oApproveDialog) {
				var text = this.getView().byId("approvalComments").getValue();
				var oData = {
					"UI_STATE": "APR",
					"UI_STATUS": "PFA",
					"REASON_TXT": text
				};
				var oModel = this.getModel();
				oModel.update(oEvent.getSource().getBindingContext().sPath, oData, {
					success: function (oEvent) {
						oModel.refresh();
						/*var errMsg = this.getView().getModel("EntityEditModel").getData().UI_ERR_MSG;
						if(errMsg){
							sap.m.MessageBox.error("Error while updating ->"+ errMsg);	
						}else{
							sap.m.MessageToast.show("Successfully Approved");
						}*/
						sap.m.MessageToast.show("Successfully Approved");
					},
					error: function (oEvent) {
						//sap.m.MessageBox.error("Some Error occured");
					}
				});
				//process
				/*var oModel = this.getModel();
				console.log(oModel.getChangeGroups());
				oModel.submitChanges({
					success: function (oEvent) {
						sap.m.MessageToast.show("Successful Approved");
						oModel.refresh();
						//that.byId("editTaskDialog").close();
					},
					error: function (oEvent) {
						sap.m.MessageBox.error("Some Error occured");
					}
				});*/
				this.oApproveDialog.close();
			}
		},
		handleApproveDialogCancel: function (oEvent) {
			if (this.oApproveDialog) {
				this.oApproveDialog.close();
			}
		},
		handleApproveAllDialogConfirm: function (oEvent) {
			if (this.oApproveAllDialog) {
				var text = this.getView().byId("approvalAllComments").getValue();
				var oTable = this.byId("expressionsTable1"),
					that = this,
					oContexts = oTable.getSelectedContexts();
				if (oContexts && oContexts.length) {
					var oModel = that.getModel();
					oModel.setUseBatch(true);
					//console.log(oContexts.length);
					oContexts.map(function (oContext) {
						//console.log("count");
						var oData = {
							"UI_STATE": "APR",
							"UI_STATUS": "PFA",
							"REASON_TXT": text
						};
						oModel.update(oContext.sPath, oData, {
							success: function (oEvent) {
								//sap.m.MessageToast.show("SuccessfulLY Approved");
								//oModel.refresh();
							},
							error: function (oEvent) {
								//sap.m.MessageBox.error("Some Error occured");
							}
						});
					});
				}
				this.oApproveAllDialog.close();
			}
		},
		handleApproveAllDialogCancel: function (oEvent) {
			if (this.oApproveAllDialog) {
				this.oApproveAllDialog.close();
			}
		},
		handleReturnDialogConfirm: function (oEvent) {
			if (this.oReturnDialog) {
				var text = this.getView().byId("returnComments").getValue();
				if (text && text.length > 0) {
					var oData = {
						"UI_STATE": "RET",
						"UI_STATUS": "PFA",
						"REASON_TXT": text
					};
					var oModel = this.getModel();
					oModel.update(oEvent.getSource().getBindingContext().sPath, oData, {
						success: function (oEvent) {
							sap.m.MessageToast.show("Successfully returned");
							oModel.refresh();
						},
						error: function (oEvent) {
							//sap.m.MessageBox.error("Some Error occured");
						}
					});
					this.oReturnDialog.close();
				} else {
					sap.m.MessageBox.error("Please enter Return comments");
				}

			}
		},
		handleReturnDialogCancel: function (oEvent) {
			if (this.oReturnDialog) {
				this.oReturnDialog.close();
			}
		},
		handleDeleteDialogConfirm: function (oEvent) {
			if (this.oDeleteDialog) {
				var text = this.getView().byId("deleteComments").getValue();
				if (text && text.length > 0) {
					var oData = {
						"UI_STATE": "EDT",
						"UI_STATUS": "DEL",
						"REASON_TXT": text
					};
					var oModel = this.getModel();
					oModel.update(oEvent.getSource().getBindingContext().sPath, oData, {
						success: function (oEvent) {
							sap.m.MessageToast.show("Successfully sent for delete approval");
							oModel.refresh();
						},
						error: function (oEvent) {
							//sap.m.MessageBox.error("Some Error occured");
						}
					});
					this.oDeleteDialog.close();
				} else {
					sap.m.MessageBox.error("Please enter Delete comments");
				}
			}
		},
		handleDeleteDialogCancel: function (oEvent) {
			if (this.oDeleteDialog) {
				this.oDeleteDialog.close();
			}
		},
		handleHistoryDialogCancel: function (oEvent) {
			if (this.oHistoryDialog) {
				this.oHistoryDialog.close();
			}
		},
		handleCancelViewPress: function (oEvent) {
			if (this.oViewDialog) {
				this.oViewDialog.close();
			}
		},

		//Common utils for editor
		setTextArea: function (textArea, appendleadingspace, selectedTag) {
			if (appendleadingspace) {
				textArea.setValue(textArea.getValue().concat(" " + selectedTag));
				//this.insertAtCursor(textArea,(" " + selectedTag));
			} else {
				textArea.setValue(textArea.getValue().concat(selectedTag));
				//this.insertAtCursor(textArea, selectedTag);
			}
		},
		/*insertAtCursor: function (textArea, myValue) {
			var myField = document.getElementById(textArea.getId()); //IE support
			if (document.selection) {
				myField.focus();
				sel = document.selection.createRange();
				sel.text = myValue;
			}
			//MOZILLA and others
			else if (myField.selectionStart || myField.selectionStart == '0') {
				var startPos = myField.selectionStart;
				var endPos = myField.selectionEnd;
				myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
			} else {
				myField.value += myValue;
			}
		},*/
		setbuttons: function (btnId, textArea) {
			if (btnId.endsWith("add")) {
				this.setTextArea(textArea, true, "+");
			} else if (btnId.endsWith("subtract")) {
				this.setTextArea(textArea, true, "-");
			} else if (btnId.endsWith("multiply")) {
				this.setTextArea(textArea, true, "*");
			} else if (btnId.endsWith("divide")) {
				this.setTextArea(textArea, true, "/");
			} else if (btnId.endsWith("open")) {
				this.setTextArea(textArea, false, "(");
			} else if (btnId.endsWith("close")) {
				this.setTextArea(textArea, false, ")");
			} else if (btnId.endsWith("min")) {
				this.setTextArea(textArea, true, "MIN");
			} else if (btnId.endsWith("max")) {
				this.setTextArea(textArea, true, "MAX");
			} else if (btnId.endsWith("average")) {
				this.setTextArea(textArea, true, "AVG");
			} else if (btnId.endsWith("count")) {
				this.setTextArea(textArea, true, "COUNT");
			} else if (btnId.endsWith("std")) {
				this.setTextArea(textArea, true, "STDDEV");
			}
		},
		convertFrequency : function(sValue, element){
			var response = sValue.FREQUENCY;
			var frequency = element.getSelectedItem() === null ? "MINS" : element.getSelectedItem().getKey();
			if(frequency === "HOURS"){
				response= sValue.FREQUENCY*60;
			}else if(frequency === "DAYS"){
				response = sValue.FREQUENCY*60*24;
			}
			return response;
		},

		//JSON manipulation-------------------------------------------
		contains: function (arr, key, val) {
			for (var i = 0; i < arr.length; i++) {
				if (arr[i][key] === val) return true;
			}
			return false;
		},
		containsObject: function (arr, key, val) {
			for (var i = 0; i < arr.length; i++) {
				if (arr[i][key] === val) return arr[i];
			}
			return null;
		},
		filterData: function (arr, col) {
			return arr.filter((el) => {
				return el.sPath !== col;
			});
		},
		checkFilter: function (col, selectedKey) {
			if (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1) {
				_oFilters = new Filter([new Filter(col, FilterOperator.EQ, selectedKey)], true);
			} else if (!this.contains(_oFilters.aFilters, "sPath", col)) {
				_oFilters.aFilters = this.filterData(_oFilters.aFilters, col);
				_oFilters.aFilters.push(new Filter(col, FilterOperator.EQ, selectedKey));
			} else if(this.contains(_oFilters.aFilters, "sPath", col) && (this.containsObject(_oFilters.aFilters, "sPath", col)).oValue1 !== selectedKey){
				_oFilters.aFilters = this.filterData(_oFilters.aFilters, col);
				_oFilters.aFilters.push(new Filter(col, FilterOperator.EQ, selectedKey));
			}
		},
		checkOperation: function (str, searchfield, addfield, editfield) {
			if (str.endsWith(searchfield)) {
				this._operation = "search";
			} else if (str.endsWith(addfield)) {
				this._operation = "add";
			} else if (str.endsWith(editfield)) {
				this._operation = "edit";
			}
		},
		setValues: function (value, valueKey, elementsearch, elementadd, elementedit) {
			if (this._operation === "search") {
				elementsearch.setValue(valueKey);
			} else if (this._operation === "add") {
				elementadd.setValue(valueKey);
			} else if (this._operation === "edit") {
				elementedit.setValue(valueKey);
			}
		},

		//validate 
		validatePlant: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT") || (oEvent.getSource().getId().endsWith("SelectedId") && (this.byId(
					"plantSelectedId").getValue() === "" || this.byId("plantSelectedId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("edit") && (this.byId("editPlantId")
					.getValue() === "" || this.byId("editPlantId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("master") && (this._plantInput
					.getValue() === "" || this._plantInput.getValue().trim() === ""))) 
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editPlantId") || !this.byId("editPlantId").getValue())) {
					MessageToast.show("Please select a plant");
					return false;
				} else if(this.byId("editPlantId") && this.byId("editPlantId").getValue()){
					this.checkFilter("PLANT", this.byId("editPlantId").getValue());
				}
			}
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("plantSelectedId") || !this.byId("plantSelectedId").getValue())) {
					MessageToast.show("Please select a plant");
					return false;
				} else if(this.byId("plantSelectedId") && this.byId("plantSelectedId").getValue()){
					this.checkFilter("PLANT", this.byId("plantSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (!this._plantInput || !this._plantInput.getValue()) {
					MessageToast.show("Please select a plant");
					return false;
				} else if(this._plantInput && this._plantInput.getValue()){
					this.checkFilter("PLANT", this._plantInput.getValue());
				}
			}
			return true;
		},
		validatePlantSection: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 //|| !_oFilters.aFilters.filter(a => a.sPath === "PLANT")
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT_SEC") || (oEvent.getSource().getId().endsWith("SelectedId") && (this.byId(
					"plantSectionSelectedId").getValue() === "" || this.byId("plantSectionSelectedId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("edit") && (this.byId("editPlantSectionId")
					.getValue() === "" || this.byId("editPlantSectionId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("master") && (this._plantSectionInput
					.getValue() === "" || this._plantSectionInput.getValue().trim() === ""))) 
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editPlantSectionId") || !this.byId("editPlantSectionId").getValue())) {
					MessageToast.show("Please select a plant");
					return false;
				} else if(this.byId("editPlantSectionId") && this.byId("editPlantSectionId").getValue()){
					this.checkFilter("PLANT_SEC", this.byId("editPlantSectionId").getValue());
				}
			}
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("plantSectionSelectedId") || !this.byId("plantSectionSelectedId").getValue())) {
					MessageToast.show("Please select a plant");
					return false;
				} else if(this.byId("plantSectionSelectedId") && this.byId("plantSectionSelectedId").getValue()){
					this.checkFilter("PLANT_SEC", this.byId("plantSectionSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (mandatoryInvalid &&(!this._plantSectionInput || !this._plantSectionInput.getValue())) {
					MessageToast.show("Please select a plant Section");
					return false;
				} else if(this._plantSectionInput && this._plantSectionInput.getValue()){
					this.checkFilter("PLANT_SEC", this._plantSectionInput.getValue());
				}
			}
			return true;
		},
		validatePlantLocation: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 //|| !_oFilters.aFilters.filter(a => a.sPath === "PLANT")
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT_LOC") || (oEvent.getSource().getId().endsWith("SelectedId") && (this.byId(
					"plantLocationSelectedId").getValue() === "" || this.byId("plantLocationSelectedId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("edit") && (this.byId("editPlantLocationId")
					.getValue() === "" || this.byId("editPlantLocationId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("master") && (this._plantLocationInput
					.getValue() === "" || this._plantLocationInput.getValue().trim() === ""))) 
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editPlantLocationId") || !this.byId("editPlantLocationId").getValue())) {
					MessageToast.show("Please select a plant");
					return false;
				} else if(this.byId("editPlantLocationId") && this.byId("editPlantLocationId").getValue()){
					this.checkFilter("PLANT_LOC", this.byId("editPlantLocationId").getValue());
				}
			}
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("plantLocationSelectedId") || !this.byId("plantLocationSelectedId").getValue())) {
					MessageToast.show("Please select a plant Location");
					return false;
				} else if(this.byId("plantLocationSelectedId") && this.byId("plantLocationSelectedId").getValue()){
					this.checkFilter("PLANT_LOC", this.byId("plantLocationSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (mandatoryInvalid && (!this._plantLocationInput || !this._plantLocationInput.getValue())) {
					MessageToast.show("Please select a plant Location");
					return false;
				} else if(this._plantLocationInput && this._plantLocationInput.getValue()){
					this.checkFilter("PLANT_LOC", this._plantLocationInput.getValue());
				}
			}
			return true;
		},
		validateFunctionLocation: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 //|| !_oFilters.aFilters.filter(a => a.sPath === "PLANT")
				|| !this.contains(_oFilters.aFilters, "sPath", "FUNC_LOC") || (oEvent.getSource().getId().endsWith("SelectedId") && (this.byId(
					"functionLocationSelectedId").getValue() === "" || this.byId("functionLocationSelectedId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("edit") && (this.byId("editFunctionLocationId")
					.getValue() === "" || this.byId("editFunctionLocationId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("master") && (this._functionLocationInput
					.getValue() === "" || this._functionLocationInput.getValue().trim() === ""))) 
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editFunctionLocationId") || !this.byId("editFunctionLocationId").getValue())) {
					MessageToast.show("Please select a function location");
					return false;
				} else if(this.byId("editFunctionLocationId") && this.byId("editFunctionLocationId").getValue()){
					this.checkFilter("FUNC_LOC", this.byId("editFunctionLocationId").getValue());
				}
			}
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("functionLocationSelectedId") || !this.byId("functionLocationSelectedId").getValue())) {
					MessageToast.show("Please select a function location");
					return false;
				} else if(this.byId("functionLocationSelectedId") && this.byId("functionLocationSelectedId").getValue()){
					this.checkFilter("FUNC_LOC", this.byId("functionLocationSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (mandatoryInvalid && (!this._functionLocationInput || !this._functionLocationInput.getValue())) {
					MessageToast.show("Please select a function location");
					return false;
				} else if(this._functionLocationInput && this._functionLocationInput.getValue()){
					this.checkFilter("FUNC_LOC", this._functionLocationInput.getValue());
				}
			}
			return true;
		},
		validatePlannerGroup: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 //|| !_oFilters.aFilters.filter(a => a.sPath === "PLANT")
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANNER_GRP") || (oEvent.getSource().getId().endsWith("SelectedId") && (this.byId(
					"plannerGroupSelectedId").getValue() === "" || this.byId("plannerGroupSelectedId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("edit") && (this.byId("editPlannerGroupId")
					.getValue() === "" || this.byId("editPlannerGroupId").getValue().trim() === ""))
					|| (oEvent.getSource().getId().includes("master") && (this._plannerGroupInput
					.getValue() === "" || this._plannerGroupInput.getValue().trim() === ""))) 
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editPlannerGroupId") || !this.byId("editPlannerGroupId").getValue())) {
					MessageToast.show("Please select a planner group");
					return false;
				} else if(this.byId("editPlannerGroupId") && this.byId("editPlannerGroupId").getValue()){
					this.checkFilter("PLANNER_GRP", this.byId("editPlannerGroupId").getValue());
				}
			}
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("plannerGroupSelectedId") || !this.byId("plannerGroupSelectedId").getValue())) {
					MessageToast.show("Please select a planner group");
					return false;
				} else if(this.byId("plannerGroupSelectedId") && this.byId("plannerGroupSelectedId").getValue()){
					this.checkFilter("PLANNER_GRP", this.byId("plannerGroupSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (mandatoryInvalid && (!this._plannerGroupInput || !this._plannerGroupInput.getValue())) {
					MessageToast.show("Please select a planner group");
					return false;
				} else if(this._plannerGroupInput && this._plannerGroupInput.getValue()){
					this.checkFilter("PLANNER_GRP", this._plannerGroupInput.getValue());
				}
			}
			return true;
		},
		validateEquipment: function (oEvent, required) {
			if (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 //|| !_oFilters.aFilters.filter(a => a.sPath === "PLANT")
				|| !this.contains(_oFilters.aFilters, "sPath", "EQUIPMENT") || (oEvent.getSource().getId().includes("master") && (this._equipmentInput
					.getValue() === "" || this._equipmentInput.getValue().trim() === "")) || (oEvent.getSource().getId().includes("edit") && (
					this.byId("editEquipmentId").getValue() === "" || this.byId("editEquipmentId").getValue().trim() === "")) || 
					(oEvent.getSource().getId().endsWith("SelectedId") && (
					this.byId("equipmentSelectedId").getValue() === "" || this.byId("equipmentSelectedId").getValue().trim() === ""))
			) {
				if (oEvent.getSource().getId().includes("master")) {
					if (!this._equipmentInput || !this._equipmentInput.getValue()) {
						MessageToast.show("Please select a equipment");
						return false;
					} else {
						this.checkFilter("EQUIPMENT", this._equipmentInput.getValue());
					}
				}
				if (oEvent.getSource().getId().endsWith("SelectedId")) {
					if (!this.byId("equipmentSelectedId") || !this.byId("equipmentSelectedId").getValue()) {
						MessageToast.show("Please select a equipment");
						return false;
					} else {
						this.checkFilter("EQUIPMENT", this.byId("equipmentSelectedId").getValue());
					}
				}
				if (oEvent.getSource().getId().includes("edit")) {
					if (!this.byId("editEquipmentId") || !this.byId("editEquipmentId").getValue()) {
						MessageToast.show("Please select a equipment");
						return false;
					} else {
						this.checkFilter("EQUIPMENT", this.byId("editEquipmentId").getValue());
					}
				}
			}
			var oFilter = this.containsObject(_oFilters.aFilters, "sPath", "EQUIPMENT").oValue1;
			if (oEvent.getSource().getId().includes("master") &&
				(this._equipmentInput.getValue() != oFilter && !this._equipmentInput.getValue().includes(oFilter))) {
				_oFilters.aFilters = this.filterData(_oFilters.aFilters, "EQUIPMENT");
				_oFilters.aFilters.push(new Filter("EQUIPMENT", FilterOperator.EQ, this._equipmentInput.getValue()));
			}
			if (oEvent.getSource().getId().endsWith("SelectedId") &&
				(this.byId("equipmentSelectedId").getValue() != oFilter && !this.byId("equipmentSelectedId").getValue().startsWith(oFilter))) {
				_oFilters.aFilters = this.filterData(_oFilters.aFilters, "EQUIPMENT");
				_oFilters.aFilters.push(new Filter("EQUIPMENT", FilterOperator.EQ, this.byId("equipmentSelectedId").getValue()));
			}
			if (oEvent.getSource().getId().includes("edit") &&
				(this.byId("editEquipmentId").getValue() != oFilter && !this.byId("editEquipmentId").getValue().startsWith(oFilter))) {
				_oFilters.aFilters = this.filterData(_oFilters.aFilters, "EQUIPMENT");
				_oFilters.aFilters.push(new Filter("EQUIPMENT", FilterOperator.EQ, this.byId("editEquipmentId").getValue()));
			}
			return true;

		},
		validatePlantPlantSectionPlantLocation: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT") 
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT_SEC") 
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT_LOC") 
				||(oEvent.getSource().getId().includes("master") &&
					(this._plantInput.getValue() === "" || this._plantInput.getValue().trim() === "" || this._plantSectionInput.getValue() === "" ||
						this._plantSectionInput.getValue().trim() === "" || this._plantLocationInput.getValue() === "" || this._plantLocationInput.getValue()
						.trim() === "")) ||
				(oEvent.getSource().getId().endsWith("SelectedId") &&
					(this.byId("plantSelectedId").getValue() === "" || this.byId("plantSelectedId").getValue().trim() === "" || this.byId(
						"plantSectionSelectedId").getValue() === "" || this.byId("plantSectionSelectedId").getValue().trim() === "" || this.byId(
						"plantLocationSelectedId").getValue() === "" || this.byId("plantLocationSelectedId").getValue().trim() === "")) ||
				(oEvent.getSource().getId().includes("edit") &&
					(this.byId("editPlantId").getValue() === "" || this.byId("editPlantId").getValue().trim() === "" || this.byId(
						"editPlantSectionId").getValue() === "" || this.byId("editPlantSectionId").getValue().trim() === "" || this.byId(
						"editPlantLocationId").getValue() === "" || this.byId("editPlantLocationId").getValue().trim() === "")))
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (mandatoryInvalid && (!this._plantInput || !this._plantInput.getValue() || !this._plantSectionInput || !this._plantSectionInput.getValue() || !this
					._plantLocationInput || !this._plantLocationInput.getValue())) {
					MessageToast.show("Please select a plant, plant section and plant location.");
					return false;
				} 
				if (this._plantInput && this._plantInput.getValue()){
					this.checkFilter("PLANT", this._plantInput.getValue());
				}
				if( this._plantSectionInput && this._plantSectionInput.getValue()){ 
					this.checkFilter("PLANT_SEC", this._plantSectionInput.getValue());
				}
				if(this._plantLocationInput && this._plantLocationInput.getValue()){
					this.checkFilter("PLANT_LOC", this._plantLocationInput.getValue());
				}
			}
	
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("plantSelectedId") || !this.byId("plantSelectedId").getValue() || !this.byId("plantSectionSelectedId") || !this.byId(
						"plantSectionSelectedId").getValue() || !this.byId("plantLocationSelectedId") || !this.byId("plantLocationSelectedId").getValue())) {
					MessageToast.show("Please select a plant, plant section and plant location.");
					return false;
				} 
				if (this.byId("plantSelectedId") && this.byId("plantSelectedId").getValue()){
					this.checkFilter("PLANT", this.byId("plantSelectedId").getValue());
				}
				if( this.byId("plantSectionSelectedId") && this.byId("plantSectionSelectedId").getValue()){ 
					this.checkFilter("PLANT_SEC", this.byId("plantSectionSelectedId").getValue());
				}
				if(this.byId("plantLocationSelectedId") && this.byId("plantLocationSelectedId").getValue()){
					this.checkFilter("PLANT_LOC", this.byId("plantLocationSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editPlantId") || !this.byId("editPlantId").getValue() || !this.byId("editPlantSectionId") || !this.byId(
						"editPlantSectionId").getValue() || !this.byId("editPlantLocationId") || !this.byId("editPlantLocationId").getValue())) {
					MessageToast.show("Please select a plant, plant section and plant location.");
					return false;
				} 
				if (this.byId("editPlantId") && this.byId("editPlantId").getValue()){
					this.checkFilter("PLANT", this.byId("editPlantId").getValue());
				}
				if( this.byId("editPlantSectionId") && this.byId("editPlantSectionId").getValue()){ 
					this.checkFilter("PLANT_SEC", this.byId("editPlantSectionId").getValue());
				}
				if(this.byId("editPlantLocationId") && this.byId("editPlantLocationId").getValue()){
					this.checkFilter("PLANT_LOC", this.byId("editPlantLocationId").getValue());
				}
			}
			return true;
		},
		validatePlantPlannerGroup: function (oEvent, required) {
			var mandatoryInvalid = false;
			if (required && (!_oFilters || !_oFilters.aFilters || !_oFilters.aFilters.length >= 1 
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANT") 
				|| !this.contains(_oFilters.aFilters, "sPath", "PLANNER_GRP") 
				||(oEvent.getSource().getId().includes("master") &&
					(this._plantInput.getValue() === "" || this._plantInput.getValue().trim() === "" || this._plannerGroupInput.getValue() === "" ||
						this._plannerGroupInput.getValue().trim() === "" )) ||
				(oEvent.getSource().getId().endsWith("SelectedId") &&
					(this.byId("plantSelectedId").getValue() === "" || this.byId("plantSelectedId").getValue().trim() === "" || this.byId(
						"plannerGroupSelectedId").getValue() === "" || this.byId("plannerGroupSelectedId").getValue().trim() === ""
						)) ||
				(oEvent.getSource().getId().includes("edit") &&
					(this.byId("editPlantId").getValue() === "" || this.byId("editPlantId").getValue().trim() === "" || this.byId(
						"editPlannerGroupId").getValue() === "" || this.byId("editPlannerGroupId").getValue().trim() === "" )))
			) {
				mandatoryInvalid = true;
			}
			if (oEvent.getSource().getId().includes("master")) {
				if (mandatoryInvalid && (!this._plantInput || !this._plantInput.getValue() || !this._plannerGroupInput || !this._plannerGroupInput.getValue() )) {
					MessageToast.show("Please select a plant and planner group.");
					return false;
				} 
				if (this._plantInput && this._plantInput.getValue()){
					this.checkFilter("PLANT", this._plantInput.getValue());
				}
				if( this._plannerGroupInput && this._plannerGroupInput.getValue()){ 
					this.checkFilter("PLANNER_GRP", this._plannerGroupInput.getValue());
				}
			}
	
			if (oEvent.getSource().getId().endsWith("SelectedId")) {
				if (mandatoryInvalid && (!this.byId("plantSelectedId") || !this.byId("plantSelectedId").getValue() || !this.byId("plannerGroupSelectedId") || !this.byId(
						"plannerGroupSelectedId").getValue())) {
					MessageToast.show("Please select a plant and planner group.");
					return false;
				} 
				if (this.byId("plantSelectedId") && this.byId("plantSelectedId").getValue()){
					this.checkFilter("PLANT", this.byId("plantSelectedId").getValue());
				}
				if( this.byId("plannerGroupSelectedId") && this.byId("plannerGroupSelectedId").getValue()){ 
					this.checkFilter("PLANNER_GRP", this.byId("plannerGroupSelectedId").getValue());
				}
			}
			if (oEvent.getSource().getId().includes("edit")) {
				if (mandatoryInvalid && (!this.byId("editPlantId") || !this.byId("editPlantId").getValue() || !this.byId("editPlannerGroupId") || !this.byId(
						"editPlannerGroupId").getValue() )) {
					MessageToast.show("Please select a plant and planner group.");
					return false;
				} 
				if (this.byId("editPlantId") && this.byId("editPlantId").getValue()){
					this.checkFilter("PLANT", this.byId("editPlantId").getValue());
				}
				if( this.byId("editPlannerGroupId") && this.byId("editPlannerGroupId").getValue()){ 
					this.checkFilter("PLANNER_GRP", this.byId("editPlannerGroupId").getValue());
				}
			}
			return true;
		},

		// PLANT methods ----------------------------------------------
		handlePlantSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("PLANT", sap.ui.model.FilterOperator.EQ, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handlePlantValueHelp: function (oEvent) {
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog1) {
				this._oValueHelpDialog1 = sap.ui.xmlfragment(
					"com.expressionappr.fragment.PlantDialog",
					this
				);
				this.getView().addDependent(this._oValueHelpDialog1);
			}
			this._oValueHelpDialog1.open();
			this.checkOperation(oEvent.getSource().getId(), "plantId", "plantSelectedId", "editPlantId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handlePlantValueHelpClose: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selectedPlant = aContexts.map(function (oContext) {
					return oContext.getObject().PLANT + " - " + oContext.getObject().PLANT_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().PLANT;
				});
				this.setValues(selectedPlant, selectedKey, this._plantInput, this.byId("plantSelectedId"), this.byId("editPlantId"));
				_oFilters = new Filter([new Filter("PLANT", FilterOperator.EQ, selectedKey)], true);
				// clear all models
			}
		},

		// PLANT SECTION methods--------------------------
		handlePlantSectionSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");

			var oFilter = new Filter({
				filters: [
					new Filter({
						filters: [
							/*new Filter("PLANT_SEC", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("PLANT_SEC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("PLANT_SEC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase()),*/
							new Filter("PLANT_SEC_DESC", sap.ui.model.FilterOperator.Contains, sValue)/*,
							new Filter("PLANT_SEC_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("PLANT_SEC_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
						],
						and: false
					}),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT")
				],
				and: true
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handlePlantSectionValueHelp: function (oEvent) {

			if (!this.validatePlant(oEvent, true)) {
				return;
			}
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog2) {
				this._oValueHelpDialog2 = sap.ui.xmlfragment("com.expressionappr.fragment.PlantSectionDialog", this);
				this.getView().addDependent(this._oValueHelpDialog2);
			}

			this._oValueHelpDialog2.getBinding("items").filter([this.containsObject(_oFilters.aFilters, "sPath", "PLANT")]);

			this._oValueHelpDialog2.open();
			this.checkOperation(oEvent.getSource().getId(), "plantSectionId", "plantSectionSelectedId", "editPlantSectionId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handlePlantSectionValueHelpClose: function (oEvent) {
			//var oInput = this.byId("plantSection");
			//this._plantSectionInput.setValue(oEvent.getParameter("selectedItems").ProductName);
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selected = aContexts.map(function (oContext) {
					return oContext.getObject().PLANT_SEC + " - " + oContext.getObject().PLANT_SEC_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().PLANT_SEC;
				});
				this.setValues(selected, selectedKey, this._plantSectionInput, this.byId("plantSectionSelectedId"), this.byId("editPlantSectionId"));

				if (this.contains(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
					_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT_SEC");
				}
				_oFilters.aFilters.push(new Filter("PLANT_SEC", FilterOperator.EQ, selectedKey));
			}
		},

		// PLANT LOCATION methods-------------------------------------
		handlePlantLocationSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new Filter({
						filters: [
							/*new Filter("PLANT_LOC", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("PLANT_LOC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("PLANT_LOC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase()),*/
							new Filter("PLANT_LOC_DESC", sap.ui.model.FilterOperator.Contains, sValue)/*,
							new Filter("PLANT_LOC_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("PLANT_LOC_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
						],
						and: false
					}),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT")
				],
				and: true
			});
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"));
			}
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handlePlantLocationValueHelp: function (oEvent) {
			if (!this.validatePlant(oEvent, true)) {
				return;
			}
			this.validatePlantSection(oEvent, false);
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog3) {
				this._oValueHelpDialog3 = sap.ui.xmlfragment("com.expressionappr.fragment.PlantLocationDialog", this);
				this.getView().addDependent(this._oValueHelpDialog3);
			}
			
			var oFilter = new Filter({
				filters: [
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT")
				],
				and: true
			});
			
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"));
			}

			this._oValueHelpDialog3.getBinding("items").filter([oFilter]);

			this._oValueHelpDialog3.open();
			this.checkOperation(oEvent.getSource().getId(), "plantLocationId", "plantLocationSelectedId", "editPlantLocationId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handlePlantLocationValueHelpClose: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selected = aContexts.map(function (oContext) {
					return oContext.getObject().PLANT_LOC + " - " + oContext.getObject().PLANT_LOC_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().PLANT_LOC;
				});
				// added for one selected value for each
				//this._plantLocationInput.setValue(selected);
				this.setValues(selected, selectedKey, this._plantLocationInput, this.byId("plantLocationSelectedId"), this.byId(
					"editPlantLocationId"));

				if (this.contains(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
					_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANT_LOC");
				}
				//setting filter
				_oFilters.aFilters.push(new Filter("PLANT_LOC", FilterOperator.EQ, selectedKey));
			}
		},

		// FUNCTION LOCATION methods--------------------------------------
		handleFunctionLocationSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new Filter({
						filters: [
							new Filter("FUNC_LOC", sap.ui.model.FilterOperator.Contains, sValue)/*,
							new Filter("FUNC_LOC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("FUNC_LOC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*//*,
							new Filter("FUNC_LOC_DESC", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("FUNC_LOC_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("FUNC_LOC_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
						],
						and: false
					}),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT"),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC")
				],
				and: true
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleFunctionLocationValueHelp: function (oEvent) {
			//if (!this.validatePlant(oEvent) && !this.validatePlantSection(oEvent) && !this.validatePlantLocation(oEvent)) 
			if (!this.validatePlantPlantSectionPlantLocation(oEvent, true) ) 
			{
				return;
			}
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog4) {
				this._oValueHelpDialog4 = sap.ui.xmlfragment("com.expressionappr.fragment.FunctionLocationDialog", this);
				this.getView().addDependent(this._oValueHelpDialog4);
			}
			
			var oFilter = new Filter({
				filters: [
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT"),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC")
			],
				and: true
			});
			
			this._oValueHelpDialog4.getBinding("items").filter([oFilter]);

			this._oValueHelpDialog4.open();
			this.checkOperation(oEvent.getSource().getId(), "functionLocationId", "functionLocationSelectedId", "editFunctionLocationId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handleFunctionLocationValueHelpClose: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selected = aContexts.map(function (oContext) {
					return oContext.getObject().FUNC_LOC + " - " + oContext.getObject().FUNC_LOC_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().FUNC_LOC;
				});
				this.setValues(selected, selectedKey, this._functionLocationInput, this.byId("functionLocationSelectedId"), this.byId(
					"editFunctionLocationId"));

				if (this.contains(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
					_oFilters.aFilters = this.filterData(_oFilters.aFilters, "FUNC_LOC");
				}
				_oFilters.aFilters.push(new Filter("FUNC_LOC", FilterOperator.EQ, selectedKey));
			}
		},

		// PLANNER GROUP LOCATION methods---------------------------------
		handlePlannerGroupSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new Filter({
						filters: [
							new Filter("PLANNER_GRP", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("PLANNER_GRP", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("PLANNER_GRP", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())/*,
							new Filter("PLANNER_GRP_DESC", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("PLANNER_GRP_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("PLANNER_GRP_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
						],
						and: false
					}),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT")
				],
				and: true
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handlePlannerGroupValueHelp: function (oEvent) {

			if (!this.validatePlant(oEvent, true)) {
				return;
			}
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog5) {
				this._oValueHelpDialog5 = sap.ui.xmlfragment("com.expressionappr.fragment.PlannerGroupDialog", this);
				this.getView().addDependent(this._oValueHelpDialog5);
			}

			this._oValueHelpDialog5.getBinding("items").filter([this.containsObject(_oFilters.aFilters, "sPath", "PLANT")]);

			this._oValueHelpDialog5.open();
			this.checkOperation(oEvent.getSource().getId(), "plannerGroupId", "plannerGroupSelectedId", "editPlannerGroupId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handlePlannerGroupValueHelpClose: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selected = aContexts.map(function (oContext) {
					return oContext.getObject().PLANNER_GRP + " - " + oContext.getObject().PLANNER_GRP_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().PLANNER_GRP;
				});
				this.setValues(selected, selectedKey, this._plannerGroupInput, this.byId("plannerGroupSelectedId"), this.byId(
					"editPlannerGroupId"));

				if (this.contains(_oFilters.aFilters, "sPath", "PLANNER_GRP")) {
					_oFilters.aFilters = this.filterData(_oFilters.aFilters, "PLANNER_GRP");
				}
				_oFilters.aFilters.push(new Filter("PLANNER_GRP", FilterOperator.EQ, selectedKey));
			}
		},

		// EQUIPMENT methods---------------------------------------------
		handleEquipmentSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new Filter({
						filters: [
							/*new Filter("EQUIPMENT", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("EQUIPMENT", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("EQUIPMENT", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase()),*/
							new Filter("EQUIPMENT_DESC", sap.ui.model.FilterOperator.Contains, sValue)/*,
							new Filter("EQUIPMENT_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("EQUIPMENT_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
						],
						and: false
					}),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT"),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP")
				],
				and: true
			});
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC"));
			}
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleEquipmentValueHelp: function (oEvent) {
			if (!this.validatePlantPlannerGroup(oEvent, true)) {
				return;
			}
			this.validatePlantSection(oEvent, false);
			this.validatePlantLocation(oEvent, false);
			this.validateFunctionLocation(oEvent, false);
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog6) {
				this._oValueHelpDialog6 = sap.ui.xmlfragment("com.expressionappr.fragment.EquipmentDialog", this);
				this.getView().addDependent(this._oValueHelpDialog6);
			}
			var oFilter = new Filter({
				filters: [
					this.containsObject(_oFilters.aFilters, "sPath", "PLANT"),
					this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP")
				],
				and: true
			});
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC"));
			}
			this._oValueHelpDialog6.getBinding("items").filter([oFilter]);

			this._oValueHelpDialog6.open();
			this.checkOperation(oEvent.getSource().getId(), "equipmentId", "equipmentSelectedId", "editEquipmentId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handleEquipmentValueHelpClose: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts"),
				that = this;
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selected = aContexts.map(function (oContext) {
					that.getModel("globalModel").setProperty("/equipmentdesc", oContext.getObject().EQUIPMENT_DESC);
					return oContext.getObject().EQUIPMENT + " - " + oContext.getObject().EQUIPMENT_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().EQUIPMENT;
				});
				this.setValues(selected, selectedKey, this._equipmentInput, this.byId("equipmentSelectedId"), this.byId("editEquipmentId"));
				if (this.contains(_oFilters.aFilters, "sPath", "EQUIPMENT")) {
					_oFilters.aFilters = this.filterData(_oFilters.aFilters, "EQUIPMENT");
				}
				_oFilters.aFilters.push(new Filter("EQUIPMENT", FilterOperator.EQ, selectedKey.toString().replace(/^0+/, '')));
			}
		},

		// MEASURE POINT methods-----------------------------------------
		handleMeasurePointSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new Filter({
						filters: [
							new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue)
							/*new Filter("MEASUR_POINT", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("MEASUR_POINT", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("MEASUR_POINT", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase()),
							new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue),
							new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
							new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
						],
						and: false
					}),
					this.containsObject(_oFilters.aFilters, "sPath", "EQUIPMENT")
				],
				and: true
			});
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP"));
			}
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleMeasurePointValueHelp: function (oEvent) {
			if (!this.validateEquipment(oEvent)) {
				return;
			}
			sap.ui.core.BusyIndicator.show(5);
			if (!this._oValueHelpDialog7) {
				this._oValueHelpDialog7 = sap.ui.xmlfragment("com.expressionappr.fragment.MeasurePointDialog", this);
				this.getView().addDependent(this._oValueHelpDialog7);
			}

			var oFilter = new Filter({
				filters: [
					this.containsObject(_oFilters.aFilters, "sPath", "EQUIPMENT")
				],
				and: true
			});
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_SEC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANT_LOC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "FUNC_LOC"));
			}
			if (this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP")) {
				oFilter.aFilters.push(this.containsObject(_oFilters.aFilters, "sPath", "PLANNER_GRP"));
			}

			this._oValueHelpDialog7.getBinding("items").filter([oFilter]);

			this._oValueHelpDialog7.open();
			this.checkOperation(oEvent.getSource().getId(), "measurePointId", "", "editMeasurePointId");
			sap.ui.core.BusyIndicator.hide();

			//set - unset fields on add and edit screen - should i ?
			//fetch oEvent and check if it ends with selectedId of starts with edit.. then only process
		},
		handleMeasurePointValueHelpClose: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedKey = null;
			if (aContexts && aContexts.length) {
				var selected = aContexts.map(function (oContext) {
					return oContext.getObject().MEASUR_POINT + " - " + oContext.getObject().MEASUR_POINT_DESC;
				});
				selectedKey = aContexts.map(function (oContext) {
					return oContext.getObject().MEASUR_POINT;
				});
				this.setValues(selected, selectedKey, this._measurePointInput, this.byId(""), this.byId("editMeasurePointId"));

				if (this.contains(_oFilters.aFilters, "sPath", "MEASUR_POINT")) {
					_oFilters.aFilters = this.filterData(_oFilters.aFilters, "MEASUR_POINT");
				}
				_oFilters.aFilters.push(new Filter("MEASUR_POINT", FilterOperator.EQ, selectedKey));
			}
		},
	});
});