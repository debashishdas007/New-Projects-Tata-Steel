jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"com/expressionappr/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"com/expressionappr/test/integration/pages/Worklist",
		"com/expressionappr/test/integration/pages/Object",
		"com/expressionappr/test/integration/pages/NotFound",
		"com/expressionappr/test/integration/pages/Browser",
		"com/expressionappr/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.expressionappr.view."
	});

	sap.ui.require([
		"com/expressionappr/test/integration/WorklistJourney",
		"com/expressionappr/test/integration/ObjectJourney",
		"com/expressionappr/test/integration/NavigationJourney",
		"com/expressionappr/test/integration/NotFoundJourney",
		"com/expressionappr/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});