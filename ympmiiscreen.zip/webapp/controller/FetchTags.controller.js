var oExpressionEntity = null;

sap.ui.define([
	"com/expression/controller/Master.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function (Master, JSONModel, History, Filter, FilterOperator, MessageBox) {
	"use strict";

	return Master.extend("com.expression.controller.FetchTags", {
		onInit: function () {
			this.getRouter().getRoute("fourth").attachPatternMatched(this._onObjectMatched, this);
			this._editorIndex = -1;
			this.totalValidatedTagsUsed = [];
			this.startDelimiter = "TSLSTART";
			this.endDelimiter = "TSLEND";
			this.spaceDelimiter = "TSL_SPACE_TSL";
			var oView = this.getView();
			oView.setModel(new JSONModel({
				oIndex: undefined
			}), "ui");
		},
		onSearchMeasuringTags : function (oEvent) {
			var sValue = oEvent.getParameter("query");
			this.renderEditorTable(sValue);
		},
		
		renderEditorTable : function(sValue){
			 var  oTable = this.byId("tableEditor"),
			    oFilter = new Filter({
					filters: [
						new Filter("EQUIPMENT", FilterOperator.EQ, oExpressionEntity.EQUIPMENT)
					],
					and: true
				});
			if (sValue) {
				oFilter.aFilters.push(new Filter({
					filters: [
						new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue)
						/*new Filter("MEASUR_POINT", sap.ui.model.FilterOperator.Contains, sValue),
						new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue),
						new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue.toLowerCase()),
						new Filter("MEASUR_POINT_DESC", sap.ui.model.FilterOperator.Contains, sValue.toUpperCase())*/
					],
					and: false
				}));
			}
			oTable.bindItems({
					path: "/ET_MEASURE_POINTSet",
					template: oTable.getBindingInfo("items").template,
					filters: oFilter
				});
		},

		onSearchTags: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			if (!sQuery) {
				sQuery = "*";
			}
			var oView = this.getView(),
				oModel = this.getModel(),
				oTagsTable = this.byId("tableAvailableTags"),
				InputFilter = new Filter({
					filters: [
						new Filter("PARAM0", FilterOperator.EQ, "getTag"),
						new Filter("PARAM1", FilterOperator.EQ, "*"),
						new Filter("PARAM2", FilterOperator.EQ, "*"),
						new Filter("PARAM3", FilterOperator.EQ, sQuery),
						new Filter("PARAM4", FilterOperator.EQ, oExpressionEntity.DATASOURCE),
						new Filter("PARAM5", FilterOperator.EQ, oExpressionEntity.PLANT),
						new Filter("PARAM6", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
						new Filter("PARAM7", FilterOperator.EQ, "*"),
						new Filter("PARAM8", FilterOperator.EQ, "*")
					],
					and: true
				});
			oModel.read("/ET_MII_DATA_LISTSet", {
				filters: [InputFilter],
				success: function (oData, response) {
					var vjson = JSON.parse(oData.results[0].RET_DATA);
					var data = vjson.Rowsets.Rowset[0];
					if (data.hasOwnProperty('Row')) {
						if (data.Row[0].hasOwnProperty('ERRORMESSAGE')) {
							//error handling
							oView.setModel(new JSONModel({
								"rows": []
							}), "tags");
							sap.m.MessageBox.error(data.Row[0].ERRORMESSAGE);

						} else if (data.Row[0].hasOwnProperty('Error') && data.Row[0].Error != "") {
							//error handling
							oView.setModel(new JSONModel({
								"rows": []
							}), "tags");
							var errMsg = $(data.Row[0].Error).find("ERRORMESSAGE").text();
							sap.m.MessageBox.error(errMsg);
						} else {
							oView.setModel(new JSONModel({
								"rows": data.Row
							}), "tags");
						}
					} else {
						sap.m.MessageToast.show("No tags matching " + sQuery);
						oView.setModel(new JSONModel({
							"rows": []
						}), "tags");
					}
				},
				error: function (oError) {
					//sap.m.MessageBox.error(oError);
					//console.log(oError);
					//error handling
				}
			});
			oModel.attachRequestSent(function () {
				oTagsTable.setBusy(true);
			});
			oModel.attachRequestCompleted(function () {
				oTagsTable.setBusy(false);
			});

		},
		onfetchTagsEvent: function () {
			var oView = this.getView(),
				oModel = this.getModel(),
				oTagsTable = this.byId("tableAvailableTags"),
				InputFilter = new Filter({
					filters: [
						new Filter("PARAM0", FilterOperator.EQ, "getTag"),
						new Filter("PARAM1", FilterOperator.EQ, "*"),
						new Filter("PARAM2", FilterOperator.EQ, "*"),
						new Filter("PARAM3", FilterOperator.EQ, "*"),
						new Filter("PARAM4", FilterOperator.EQ, oExpressionEntity.DATASOURCE),
						new Filter("PARAM5", FilterOperator.EQ, oExpressionEntity.PLANT),
						new Filter("PARAM6", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
						new Filter("PARAM7", FilterOperator.EQ, "*"),
						new Filter("PARAM8", FilterOperator.EQ, "*")
					],
					and: true
				});

			oModel.read("/ET_MII_DATA_LISTSet", {
				filters: [InputFilter],
				success: function (oData, response) {
					var vjson = JSON.parse(oData.results[0].RET_DATA);
					var data = vjson.Rowsets.Rowset[0];
					if (data.hasOwnProperty('Row')) {
						if (data.Row[0].hasOwnProperty('ERRORMESSAGE')) {
							//error handling	
							sap.m.MessageBox.error(data.Row[0].ERRORMESSAGE);
						} else if (data.Row[0].hasOwnProperty('Error') && data.Row[0].Error != "") {
							//error handling
							var errMsg = $(data.Row[0].Error).find("ERRORMESSAGE").text();
							sap.m.MessageBox.error(errMsg);
						} else {
							oView.setModel(new JSONModel({
								"rows": data.Row
							}), "tags");
						}
					} else {
						sap.m.MessageToast.show("Server failed to return tag data.");
					}
				},
				error: function (oError) {
					//sap.m.MessageBox.error(oError);
					//console.log(oError);
					//error handling
				}
			});
			oModel.attachRequestSent(function () {
				oTagsTable.setBusy(true);
			});
			oModel.attachRequestCompleted(function () {
				oTagsTable.setBusy(false);
			});
		},

		backendOperate: function (status) {
			var that = this,
				oExpressionEntityData = this.getView().getModel("EntityAddModel").getData(),
				oModel = this.getModel();

			oModel.setUseBatch(true);
			var oCreateUserModel = oExpressionEntityData.filter(function (o, i) {
				oExpressionEntityData[i].UI_STATUS = status;
				oModel.createEntry("/ET_DETAILSSet", {
					properties: oExpressionEntityData[i]
				}, {
					method: "POST",
					success: function (data) {

					},
					error: function (event) {
						//sap.m.MessageBox.error("Some Error occured while creating user");
					}
				});
				return true; // stop searching
			});
			oModel.submitChanges({
				success: function (oEvent) {
					if(status && status==="SAD"){
						sap.m.MessageToast.show("Successful Draft");
					} else if(status && status==="PFA"){
						sap.m.MessageToast.show("Successful Submit");
					}
					oModel.refresh();
					that.getView().setModel(new JSONModel([]), "EntityAddModel");
					that.byId("draftBtn").setEnabled(false);
					that.byId("SubmitBtn").setEnabled(false);
					//that.byId("validateBtn").setEnabled(false);
					that.byId("discardBtn").setText("Back");
					that.byId("discardBtn").setIcon("sap-icon://back-to-top");
				},
				error: function (oEvent) {
					oModel.refresh();
					//sap.m.MessageBox.error("Some Error occured");
				}
			});
			oModel.attachRequestSent(function () {
				that.byId("pageFetchTags").setBusy(true);
			});
			oModel.attachRequestCompleted(function () {
				that.byId("pageFetchTags").setBusy(false);
			});
			
		},

		onDraftButtonPress: function () {
			this.backendOperate("SAD");
		},

		onSubmitBtnPress: function () {
			this.backendOperate("PFA");
		},

		replaceAll: function (str, find, replace) {
			return str.replace(new RegExp(find, 'gi'), replace);
		},

		updateTagsToReplace: function () {
			var y = this.getView().getModel("tags").getData();
			if (y && y.rows && y.rows.length > 0) {
				for (var i = 0; i < y.rows.length; i++) {
					var tag = y.rows[i].NativeSource;
					this.filterAndAddFetchTagsData([tag]);
				}
			}
		},

		convertExpressionToAcceptableByMIISytem: function (expression) {
			var x = this.totalValidatedTagsUsed;
			for (var i = 0; i < x.length; i++) {
				var tag = "";
				if (Array.isArray(x[i])) {
					tag = x[i][0];
				} else {
					tag = x[i];
				}
				if (tag != "" && expression.includes(tag)) {
					var newTag = tag;
					//if(datasourcecheck for space)
					if (oExpressionEntity.DATASOURCE === "SQL" || oExpressionEntity.DATASOURCE === "ORACLE") {
						newTag = this.replaceAll(tag, ' ', this.spaceDelimiter);
					}
					expression = this.replaceAll(expression, tag, this.startDelimiter + newTag + this.endDelimiter);
				}
			}
			return expression;
		},

		onValidateBtnPress: function () {
			var oTable = this.byId("tableEditor"),
				that = this,
				oItems = oTable.getSelectedItems();
			if (oItems && oItems.length) {
				this.getView().setModel(new JSONModel([]), "EntityAddModel");
				var oExpressionEntityData = this.getView().getModel("EntityAddModel").getData(),
					oModel = this.getModel();
				this.updateTagsToReplace();
				oItems.map(function (oItem) {
					var measurePointAndDescCtrl = oItem.getCells()[1],
						measurePointAndDesc = measurePointAndDescCtrl.getText(),
						measurePoint = measurePointAndDesc.substring(0, measurePointAndDesc.indexOf("-") + 1),
						measurePointDesc = measurePointAndDesc.substring(measurePointAndDesc.indexOf("-") + 2, measurePointAndDesc.length),
						expressionCtrl = oItem.getCells()[5],
						/*gtMinCtrl = oItem.getCells()[2],
						gtMaxCtrl = oItem.getCells()[3],*/
						descriptionCtrl = oItem.getCells()[6];

					//validations
					if (!expressionCtrl.getValue() || expressionCtrl.getValue() === "") {
						expressionCtrl.setValueState(sap.ui.core.ValueState.Warning);
						expressionCtrl.setTooltip("This value cannot be blank");
						return;
					}
				/*	if (!gtMinCtrl.getValue() || gtMinCtrl.getValue() === "") {
						gtMinCtrl.setValueState(sap.ui.core.ValueState.Warning);
						gtMinCtrl.setTooltip("This value cannot be blank");
						return;
					}
					if (!gtMaxCtrl.getValue() || gtMaxCtrl.getValue() === "") {
						gtMaxCtrl.setValueState(sap.ui.core.ValueState.Warning);
						gtMaxCtrl.setTooltip("This value cannot be blank");
						return;
					}*/
					if (!descriptionCtrl.getValue() || descriptionCtrl.getValue() === "") {
						descriptionCtrl.setValueState(sap.ui.core.ValueState.Warning);
						descriptionCtrl.setToolTip("This value cannot be blank");
						return;
					}
					var expression = expressionCtrl.getValue();
					expression = that.convertExpressionToAcceptableByMIISytem(expression);

					var InputFilter = new Filter({
						filters: [
							new Filter("PARAM0", FilterOperator.EQ, "vldtExp"),
							new Filter("PARAM1", FilterOperator.EQ, oExpressionEntity.DATASOURCE),
							new Filter("PARAM2", FilterOperator.EQ, expression),
							new Filter("PARAM3", FilterOperator.EQ, oExpressionEntity.PLANT_LOC),
							new Filter("PARAM4", FilterOperator.EQ, oExpressionEntity.FUNC_LOC),
							new Filter("PARAM5", FilterOperator.EQ, oExpressionEntity.EQUIPMENT),
							new Filter("PARAM6", FilterOperator.EQ, oExpressionEntity.PLANNER_GRP),
							new Filter("PARAM7", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
							new Filter("PARAM8", FilterOperator.EQ, oExpressionEntity.PLANT)
						],
						and: true
					});

					oModel.read("/ET_MII_DATA_LISTSet", {
						filters: [InputFilter],
						success: function (oData, response) {
							var vjson = JSON.parse(oData.results[0].RET_DATA);
							var data = vjson.Rowsets.Rowset[0];
							if (data.hasOwnProperty('Row')) {
								//testing :start
								if (data.Row[0].hasOwnProperty('ERRORMESSAGE')) {
									//error handling - some popup that takes it back to home page
									expressionCtrl.setValueState(sap.ui.core.ValueState.Error);
									expressionCtrl.setTooltip(data.Row[0].ERRORMESSAGE);
								} else if (data.Row[0].hasOwnProperty('Error') && data.Row[0].Error != "") {
									var errMsg = $(data.Row[0].Error).find("ERRORMESSAGE").text();
									expressionCtrl.setValueState(sap.ui.core.ValueState.Error);
									expressionCtrl.setTooltip(errMsg);
									/*gtMinCtrl.setValueState(sap.ui.core.ValueState.Error);
									gtMinCtrl.setTooltip(errMsg);
									gtMaxCtrl.setValueState(sap.ui.core.ValueState.Error);
									gtMaxCtrl.setTooltip(errMsg);
									descriptionCtrl.setValueState(sap.ui.core.ValueState.Error);
									descriptionCtrl.setTooltip(errMsg);*/
								} else
								//testing : end
								{
									//data.Row check for success
									//remove first filter
									delete oExpressionEntityData.__metadata;
									oExpressionEntityData.push({
										"PLANT": oExpressionEntity.PLANT,
										"PLANT_SEC": oExpressionEntity.PLANT_SEC,
										"PLANT_LOC": oExpressionEntity.PLANT_LOC,
										"FUNC_LOC": oExpressionEntity.FUNC_LOC,
										"PLANNER_GRP": oExpressionEntity.PLANNER_GRP,
										"EQUIPMENT": oExpressionEntity.EQUIPMENT,
										"EQUIPMENT_DESC": oExpressionEntity.EQUIPMENT_DESC,
										"MEASUREMENT_TYPE": oExpressionEntity.MEASUREMENT_TYPE,
										"GARBAGE_VALUE": oExpressionEntity.GARBAGE_CODE,
										"GARBAGE_CODE": oExpressionEntity.GARBAGE_CODE,
										//"ACTIVE": oExpressionEntity.ACTIVE ? "Y" : "N",
										"DATASOURCE": oExpressionEntity.DATASOURCE,
										"FREQUENCY": oExpressionEntity.FREQUENCY,
										"EXPRESSION": expression,
										"MEASUR_POINT": measurePoint,
										"MEASUR_POINT_DESC": measurePointDesc,
										"REMARKS": descriptionCtrl.getValue(),
										"UI_STATUS": "SAD",
										"UI_STATE": "CRT",
										/*"GTMIN": gtMinCtrl.getValue(),
										"GTMAX": gtMaxCtrl.getValue()*/
										"GTMIN": "-9999999",
										"GTMAX": "9999999"
									});
									that.getView().getModel("EntityAddModel").refresh();
									expressionCtrl.setValueState(sap.ui.core.ValueState.Success);
									expressionCtrl.setTooltip("Expression valid");
									/*gtMinCtrl.setValueState(sap.ui.core.ValueState.Success);
									gtMinCtrl.setTooltip("Expression valid");
									gtMaxCtrl.setValueState(sap.ui.core.ValueState.Success);
									gtMaxCtrl.setTooltip("Expression valid");*/
									descriptionCtrl.setValueState(sap.ui.core.ValueState.Success);
									descriptionCtrl.setTooltip("Expression valid");
									that.byId("draftBtn").setEnabled(true);
									that.byId("SubmitBtn").setEnabled(true);
								}
							} else {
								//error handling - some popup that takes it back to home page
								sap.m.MessageToast.show("Server failed to return validation data.");
							}
						},
						error: function (oError) {
							console.log(oError);
							//error handling
						}
					});
					oModel.attachRequestSent(function () {
						that.byId("pageFetchTags").setBusy(true);
					});
					oModel.attachRequestCompleted(function () {
						that.byId("pageFetchTags").setBusy(false);
					});
				});
			} else {
				MessageBox.error("Please select atleast one checkbox of the editor table");
				return;
			}
		},
		filterFetchTagsData: function (arr, val) {
			return arr.filter((el) => {
				return el[0] !== val[0];
			});
		},
		filterAndAddFetchTagsData: function (val) {
			this.totalValidatedTagsUsed = this.filterFetchTagsData(this.totalValidatedTagsUsed, val);
			this.totalValidatedTagsUsed.push(val);
		},
		moveToEditorTextArea: function () {
			var oTableAvailableTags = this.byId("tableAvailableTags");
			var oEditorTags = this.byId("tableEditor");
			var aContexts = oTableAvailableTags.getSelectedContexts();

			if (aContexts && aContexts.length) {
				var selectedTag = aContexts.map(function (oContext) {
					return oContext.getObject().NativeSource;
				});
				if (this._editorIndex === "undefined" || this._editorIndex < 0) {
					MessageBox.error("Please select an editor");
					return;
				}
				var oItem = oEditorTags.getItems()[this._editorIndex];
				this.setTextArea(oItem.getCells()[5], true, selectedTag);
				//added for tag replacement with string delimiter and tokenizer
				this.filterAndAddFetchTagsData(selectedTag);
				//var textArea = oItem.getCells()[2];
				//textArea.setValue(textArea.getValue().concat(" "+selectedTag));
			} else {
				MessageBox.error("Please select a tag");
			}
		},
		onOperationPress: function (oEvent) {
			var btnId = oEvent.getSource().getId();
			var oEditorTags = this.byId("tableEditor");
			if (this._editorIndex === "undefined" || this._editorIndex < 0) {
				MessageBox.error("Please select an editor");
				return;
			}
			var oItem = oEditorTags.getItems()[this._editorIndex];
			var textArea = oItem.getCells()[5];

			this.setbuttons(btnId, textArea);
		},
		//Editor controls------------------
		onEdit: function (oEvent) {
			var oItem = oEvent.getSource().getParent();
			var oTable = this.getView().byId("tableEditor");
			var oIndex = oTable.indexOfItem(oItem);
			this._editorIndex = oIndex;
			var oModel = this.getView().getModel("ui");
			var oFlag = oModel.getProperty("/oIndex");
			if (oFlag === undefined) {
				oModel.setProperty("/oIndex", oIndex);
				this.onPress(oItem, true);
			} else {
				var oPreviousItem = oTable.getItems()[oFlag];
				this.onPress(oPreviousItem, false);
				var oCurrentItem = oTable.getItems()[oIndex];
				oModel.setProperty("/oIndex", oIndex);
				this.onPress(oCurrentItem, true);
			}
		},
		onPress: function (oItem, oFlag) {
			var oEditableCells = oItem.getCells();
			$(oEditableCells).each(function (i) {
				var oEditableCell = oEditableCells[i];
				var oMetaData = oEditableCell.getMetadata();
				var oElement = oMetaData.getElementName();
				if (oElement == "sap.m.TextArea" || oElement == "sap.m.Input") {
					oEditableCell.setEditable(oFlag);
					if (oElement == "sap.m.TextArea" && oFlag) {
						oEditableCell.setHeight("180px");
					} else if (oElement == "sap.m.TextArea") {
						oEditableCell.setHeight("100%");
					}
				}
			});
		},
		onChangeEquipment : function(oEvent){
			//var newEquipment = oEvent.getParameter("newValue");
			oExpressionEntity.EQUIPMENT = oEvent.getSource().getSelectedItem().getKey();
			oExpressionEntity.EQUIPMENT_DESC = oEvent.getSource().getSelectedItem().getAdditionalText();
			this.renderEditorTable("");
			
		},
		
		populateEquipmentComboBox : function(){
			var oFilter = new Filter({
				filters: [
					new Filter("PLANT", sap.ui.model.FilterOperator.EQ, oExpressionEntity.PLANT),
					new Filter("PLANNER_GRP", sap.ui.model.FilterOperator.EQ, oExpressionEntity.PLANNER_GRP),
					new Filter("PLANT_SEC", sap.ui.model.FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
					new Filter("PLANT_LOC", sap.ui.model.FilterOperator.EQ, oExpressionEntity.PLANT_LOC),
					new Filter("FUNC_LOC", sap.ui.model.FilterOperator.EQ, oExpressionEntity.FUNC_LOC)
				],
				and: true
			});
			this.byId("fetchTagsEquipmentComboBoxId").getBinding("items").filter([oFilter]);	
		},
		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			oExpressionEntity = {
				"PLANT": (oEvent.getParameter("arguments").plant === "null" ? "" : oEvent.getParameter("arguments").plant),
				"PLANT_SEC": (oEvent.getParameter("arguments").plantSection === "null" ? "" : oEvent.getParameter("arguments").plantSection),
				"PLANT_LOC": (oEvent.getParameter("arguments").plantLocation === "null" ? "" : oEvent.getParameter("arguments").plantLocation),
				"FUNC_LOC": (oEvent.getParameter("arguments").functionLocation === "null" ? "" : oEvent.getParameter("arguments").functionLocation),
				"PLANNER_GRP": (oEvent.getParameter("arguments").plannerGrp === "null" ? "" : oEvent.getParameter("arguments").plannerGrp),
				"EQUIPMENT": (oEvent.getParameter("arguments").equipment === "null" ? "" : oEvent.getParameter("arguments").equipment),
				"EQUIPMENT_DESC": (oEvent.getParameter("arguments").equipmentDesc === "null" ? "" : oEvent.getParameter("arguments").equipmentDesc),
				"DATASOURCE": (oEvent.getParameter("arguments").server === "null" ? "" : oEvent.getParameter("arguments").server),
				//"TAG_FILTER": (oEvent.getParameter("arguments").tagFilter === "null" ? "S1_DRV" : oEvent.getParameter("arguments").tagFilter),
				"ACTIVE": (oEvent.getParameter("arguments").active === "null" ? "" : oEvent.getParameter("arguments").active),
				"GARBAGE_CODE": (oEvent.getParameter("arguments").garbageCode === "null" ? "" : oEvent.getParameter("arguments").garbageCode),
				"GARBAGE_VAL": (oEvent.getParameter("arguments").garbageVal === "null" ? "" : oEvent.getParameter("arguments").garbageVal),
				"MEASUREMENT_TYPE": (oEvent.getParameter("arguments").measurementType === "null" ? "" : oEvent.getParameter("arguments").measurementType),
				"FREQUENCY": (oEvent.getParameter("arguments").frequency === "null" ? "" : oEvent.getParameter("arguments").frequency)
			};

			//testing : start
			/*oExpressionEntity.PLANT = "062";
			oExpressionEntity.PLANT_SEC = "TFM";
			oExpressionEntity.PLANT_LOC = "FM2";
			oExpressionEntity.FUNC_LOC = "TS-LCR-TFM-FM_2 -DRV_SYS";
			oExpressionEntity.PLANNER_GRP = "e23";
			oExpressionEntity.EQUIPMENT = "10138294";
			oExpressionEntity.EQUIPMENT_DESC = "equipment for sthg";
			oExpressionEntity.DATASOURCE = "TSJ_CASTER";
			oExpressionEntity.ACTIVE = true;
			oExpressionEntity.GARBAGE_CODE = "EQSD";
			oExpressionEntity.GARBAGE_VAL = "Equipment under shutdown";
			oExpressionEntity.MEASUREMENT_TYPE = "notification";
			oExpressionEntity.FREQUENCY = "5";*/
			//testing: end

			//oExpressionEntity.TAG_FILTER = "*"; //"S1_DRV";
			this.getView().setModel(new JSONModel({
				"rows": []
			}), "tags");
			//arr.push(oExpressionEntity);
			this.getView().setModel(new JSONModel({
				"EQUIPMENT": oExpressionEntity.EQUIPMENT,
				"EQUIPMENT_DESC": oExpressionEntity.EQUIPMENT_DESC,
				"PLANT" : oExpressionEntity.PLANT,
				"PLANNER_GRP" : oExpressionEntity.PLANNER_GRP,
				"PLANT_SEC" : oExpressionEntity.PLANT_SEC,
				"PLANT_LOC" : oExpressionEntity.PLANT_LOC,
				"FUNC_LOC" : oExpressionEntity.FUNC_LOC
			}), "selectedVals");
			this.populateEquipmentComboBox();

			if (oExpressionEntity.DATASOURCE === "SQL" || oExpressionEntity.DATASOURCE === "ORACLE") {
				/*this.byId("open").setVisible(true);
				this.byId("close").setVisible(true);*/
				this.byId("min").setVisible(true);
				this.byId("max").setVisible(true);
				this.byId("average").setVisible(true);
				this.byId("count").setVisible(true);
				this.byId("std").setVisible(true);
			} else {
				/*this.byId("open").setVisible(false);
				this.byId("close").setVisible(false);*/
				this.byId("min").setVisible(false);
				this.byId("max").setVisible(false);
				this.byId("average").setVisible(false);
				this.byId("count").setVisible(false);
				this.byId("std").setVisible(false);
			}
			this.byId("tableAvailableTags").removeAllItems();
			var oTable = this.byId("tableEditor")
			oTable.removeAllItems();     
			oTable.bindItems({
						path: "/ET_MEASURE_POINTSet",
						template: oTable.getBindingInfo("items").template,
						filters: new Filter("EQUIPMENT", FilterOperator.EQ, oExpressionEntity.EQUIPMENT)
					});
			this.getView().setModel(new JSONModel([]), "EntityAddModel");
			this.totalValidatedTagsUsed = [];
			this.byId("searchMeasuringPoints").setValue("");
			this.byId("searchTags").setValue("");
			this.byId("validateBtn").setEnabled(true);
			this.byId("draftBtn").setEnabled(false);
			this.byId("SubmitBtn").setEnabled(false);
			this.byId("discardBtn").setText("Discard");
			this.byId("discardBtn").setIcon("sap-icon://decline");
			this.onfetchTagsEvent();
		}
	});
});