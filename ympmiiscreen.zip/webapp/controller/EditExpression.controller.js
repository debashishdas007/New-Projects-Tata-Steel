//var oExpressionEntity = null;

sap.ui.define([
	"com/expression/controller/Master.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"com/expression/model/formatter"
], function (Master, JSONModel, History, Filter, FilterOperator, MessageToast, formatter) {
	"use strict";

	return Master.extend("com.expression.controller.EditExpression", {

		formatter: formatter,
		onInit: function () {
			this.byId("pageEdit").setBusy(true);
			this.byId("tableAvailableTags").setBusy(true);
			this.getRouter().getRoute("third").attachPatternMatched(this._onObjectMatched, this);
			this.originalExpression = null;
			this.totalValidatedTagsUsed = [];
			this.startDelimiter = "TSLSTART";
			this.endDelimiter = "TSLEND";
			this.spaceDelimiter = "TSL_SPACE_TSL";
			this.isTagsFetched = false;
			var oView = this.getView();
			oView.setModel(new JSONModel({
				multiplier: "HOURS",
				plantSection : ""
			}), "ui");
		},
		_onObjectMatched: function (oEvent) {
			var that = this,
				oModel = this.getModel();
			//sObjectId = oEvent.getParameter("arguments").objectId,
			//entityURI = "/ET_DETAILSSet(guid'" + sObjectId + "')";
			this.entityURI = "/ET_DETAILSSet(guid'" + oEvent.getParameter("arguments").objectId + "')";
			this.totalValidatedTagsUsed = [];
			this.isTagsFetched = false;
			this.byId("SubmitBtn").setEnabled(true);
			this.byId("discardBtn").setText("Discard");
			this.byId("discardBtn").setIcon("sap-icon://decline");
			this.byId("GreyedOutExpressionlbl").setVisible(true);
			this.byId("GreyedOutTypeHere").setVisible(true);
			this.byId("grid").setVisible(false);
			this.byId("fetchNewTags").setText("Edit Expression");
			this.byId("fetchNewTags").setIcon("sap-icon://edit");
			
			this.getView().getModel("ui").setProperty("/multiplier", "HOURS");

			var oEditEntity = oModel.read(this.entityURI, {
				success: function (oData, response) {
					//oExpressionEntity = 
					that.byId("pageEdit").setBusy(false);
					that.getView().setModel(new JSONModel(oData), "EntityEditModel");
					that.getView().getModel("ui").setProperty("/plantSection", oData.PLANT_SEC);
					that.originalExpression = oData.EXPRESSION;
					that.calculateOriginalTagsUsed();
				},
				error: function (oError) {
					that.byId("pageEdit").setBusy(false);
					console.log(oError);
					//error handling
				}
			});
			oModel.attachRequestSent(function () {
				that.byId("pageEdit").setBusy(true);
			});
			oModel.attachRequestCompleted(function () {

				that.byId("pageEdit").setBusy(false);
			});

		},
		onSearchTags: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			if (!sQuery) {
				sQuery = "*";
			}
			var oView = this.getView(),
				oModel = this.getModel(),
				oTagsTable = this.byId("tableAvailableTags"),
				oExpressionEntity = this.getView().getModel("EntityEditModel").getData(),
				InputFilter = new Filter({
					filters: [
						new Filter("PARAM0", FilterOperator.EQ, "getTag"),
						new Filter("PARAM1", FilterOperator.EQ, "*"),
						new Filter("PARAM2", FilterOperator.EQ, "*"),
						new Filter("PARAM3", FilterOperator.EQ, sQuery),
						new Filter("PARAM4", FilterOperator.EQ, oExpressionEntity.DATASOURCE),
						new Filter("PARAM5", FilterOperator.EQ, oExpressionEntity.PLANT),
						new Filter("PARAM6", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
						new Filter("PARAM7", FilterOperator.EQ, "*"),
						new Filter("PARAM8", FilterOperator.EQ, "*")
					],
					and: true
				});
			oModel.read("/ET_MII_DATA_LISTSet", {
				filters: [InputFilter],
				success: function (oData, response) {
					var vjson = JSON.parse(oData.results[0].RET_DATA);
					var data = vjson.Rowsets.Rowset[0];
					if (data.hasOwnProperty('Row')) {
						if (data.Row[0].hasOwnProperty('ERRORMESSAGE')) {
							//error handling
							oView.setModel(new JSONModel({
								"rows": []
							}), "tags");
							sap.m.MessageBox.error(data.Row[0].ERRORMESSAGE);

						} else if (data.Row[0].hasOwnProperty('Error') && data.Row[0].Error != "") {
							//error handling
							oView.setModel(new JSONModel({
								"rows": []
							}), "tags");
							var errMsg = $(data.Row[0].Error).find("ERRORMESSAGE").text();
							sap.m.MessageBox.error(errMsg);
						} else {
							oView.setModel(new JSONModel({
								"rows": data.Row
							}), "tags");
						}
					} else {
						sap.m.MessageToast.show("No tags matching " + sQuery);
						oView.setModel(new JSONModel({
							"rows": []
						}), "tags");
					}
				},
				error: function (oError) {
					sap.m.MessageBox.error("Error while calling odata. " + oError);
					//console.log(oError);
					//error handling
				}
			});
			oModel.attachRequestSent(function () {
				oTagsTable.setBusy(true);
			});
			oModel.attachRequestCompleted(function () {
				oTagsTable.setBusy(false);
			});

		},
		inputValidation: function (oExpressionEntity, frequency) {
			var oModel = this.getModel(),
				that = this,
				InputFilter = new Filter({
					filters: [
						new Filter("PLANT", FilterOperator.EQ, oExpressionEntity.PLANT),
						new Filter("PLANT_LOC", FilterOperator.EQ, oExpressionEntity.PLANT_LOC),
						new Filter("PLANT_SEC", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
						new Filter("PLANNER_GRP", FilterOperator.EQ, oExpressionEntity.PLANNER_GRP),
						new Filter("FUNC_LOC", FilterOperator.EQ, oExpressionEntity.FUNC_LOC),
						new Filter("EQUIPMENT", FilterOperator.EQ, oExpressionEntity.EQUIPMENT),
					],
					and: true
				});
			oExpressionEntity.FREQUENCY = ""+frequency;
			oModel.read("/ET_VALIDATESet", {
				filters: [InputFilter],
				"async": false,
				success: function (oData, response) {
					if (oData && oData.results && oData.results[0]) {
						if (oData.results[0].VALID && oData.results[0].VALID === "F") {
							sap.m.MessageBox.error(oData.results[0].ERR_MSG);
						} else if (oData.results[0].VALID && oData.results[0].VALID === "S") {
								oModel.update(that.entityURI, oExpressionEntity, {

									success: function (oEvent) {
										oModel.refresh();
										var errMsg = that.getView().getModel("EntityEditModel").getData().UI_ERR_MSG;
										if (errMsg) {
											sap.m.MessageBox.error("Error while updating ->" + errMsg);
										}
										sap.m.MessageToast.show("Successfully Edited");
										that.byId("SubmitBtn").setEnabled(false);
										that.byId("discardBtn").setText("Back");
										that.byId("discardBtn").setIcon("sap-icon://back-to-top");
									},
									error: function (oError) {
										sap.m.MessageBox.error("Some Error occured" + oError);
									}
								});
					
								oModel.attachRequestSent(function () {
									that.byId("pageEdit").setBusy(true);
								});
								oModel.attachRequestCompleted(function () {
									that.byId("pageEdit").setBusy(false);
								});
						
						
							
						} else {
							sap.m.MessageBox.error("Server returned incorrect response");
						}
					} else {
						sap.m.MessageBox.error("Server returned incorrect response");
					}

				},
				error: function (oError) {
					//error handling
				}
			});
			oModel.attachRequestSent(function () {
				that.byId("pageEdit").setBusy(true);
			});
			oModel.attachRequestCompleted(function () {
				that.byId("pageEdit").setBusy(false);
			});
		},

		backendOperate: function (status) {
			var that = this,
				oExpressionEntityData = this.getView().getModel("EntityEditModel").getData(),
				valid = false,
				oModel = this.getModel();

			//TODO: fetch garbage value

			var editedExpressionEntity = {
				"PLANT": oExpressionEntityData.PLANT,
				"EQUIPMENT": oExpressionEntityData.EQUIPMENT,
				"EXPRESSION": oExpressionEntityData.EXPRESSION,
				"MEASUR_POINT": oExpressionEntityData.MEASUR_POINT,
				"PLANT_SEC": oExpressionEntityData.PLANT_SEC,
				"PLANT_LOC": oExpressionEntityData.PLANT_LOC,
				"FUNC_LOC": oExpressionEntityData.FUNC_LOC,
				"PLANNER_GRP": oExpressionEntityData.PLANNER_GRP,
				"GARBAGE_VALUE": oExpressionEntityData.GARBAGE_VALUE,
				"GARBAGE_CODE": oExpressionEntityData.GARBAGE_CODE,
				"FREQUENCY": oExpressionEntityData.FREQUENCY,
				"REMARKS": oExpressionEntityData.REMARKS,
				"REASON_TXT": oExpressionEntityData.REASON_TXT,
				"UI_STATUS": status,
				"UI_STATE": "EDT",
				"GTMIN": oExpressionEntityData.GTMIN,
				"GTMAX": oExpressionEntityData.GTMAX,
				"DATASOURCE": oExpressionEntityData.DATASOURCE,
				"MEASUREMENT_TYPE": oExpressionEntityData.MEASUREMENT_TYPE
			};
			oExpressionEntityData.UI_STATUS = status;
			oExpressionEntityData.UI_STATE = "EDT";

			//validate the expression
			for (var property in editedExpressionEntity) {
				if (editedExpressionEntity[property] !== "") {
					valid = true;
				} else {
					valid = false;
					break;
				}
			}
			if (valid) {
				this.inputValidation(editedExpressionEntity, this.convertFrequency(editedExpressionEntity, this.byId("editfrequencyMultiplierId")));
			} else {
				sap.m.MessageBox.error("Please fill all mandatory* fields");
			}

			//oModel.update("/ET_DETAILSSet(guid'"+oExpressionEntityData.EXPRESSION_ID+"')", oExpressionEntityData, {
		

		},

		onDraftButtonPress: function () {
			this.backendOperate("SAD");
		},

		onSubmitBtnPress: function () {
			this.backendOperate("PFA");
		},

		replaceAll: function (str, find, replace) {
			return str.replace(new RegExp(find, 'gi'), replace);
		},

		updateTagsToReplace: function () {
			var y = this.getView().getModel("tags").getData();
			if (y && y.rows && y.rows.length > 0) {
				for (var i = 0; i < y.rows.length; i++) {
					var tag = y.rows[i].NativeSource;
					this.filterAndAddData([tag]);
				}
			}
		},

		convertExpressionToAcceptableByMIISytem: function (expression, oExpressionEntity) {
			var x = this.totalValidatedTagsUsed;
			for (var i = 0; i < x.length; i++) {
				var tag = "";
				if (Array.isArray(x[i])) {
					tag = x[i][0];
				} else {
					tag = x[i];
				}
				if (tag != "" && expression.includes(tag)) {
					var newTag = tag;
					//if(datasourcecheck for space)
					if (oExpressionEntity.DATASOURCE === "SQL" || oExpressionEntity.DATASOURCE === "ORACLE") {
						newTag = this.replaceAll(tag, ' ', this.spaceDelimiter);
					}
					expression = this.replaceAll(expression, tag, this.startDelimiter + newTag + this.endDelimiter);
				}
			}
			return expression;
		},

		onValidateAndSubmitBtnPress: function () {
			var oExpressionEntityData = this.getView().getModel("EntityEditModel").getData(),
				that = this,
				oModel = this.getModel();

			//TODO: validate the inputs
			//validate the plant/plant sec given by gunjan odata
			//validate other values

			//convert frequency
			

			if (this.isTagsFetched) {
				var expression = this.byId("TypeHere").getValue(); //oExpressionEntityData.EXPRESSION;
				this.updateTagsToReplace();
				expression = this.convertExpressionToAcceptableByMIISytem(expression, oExpressionEntityData);

				var InputFilter = new Filter({
					filters: [
						new Filter("PARAM0", FilterOperator.EQ, "vldtExp"),
						new Filter("PARAM1", FilterOperator.EQ, oExpressionEntityData.DATASOURCE),
						new Filter("PARAM2", FilterOperator.EQ, expression),
						new Filter("PARAM3", FilterOperator.EQ, oExpressionEntityData.PLANT_LOC),
						new Filter("PARAM4", FilterOperator.EQ, oExpressionEntityData.FUNC_LOC),
						new Filter("PARAM5", FilterOperator.EQ, oExpressionEntityData.EQUIPMENT),
						new Filter("PARAM6", FilterOperator.EQ, oExpressionEntityData.PLANNER_GRP),
						new Filter("PARAM7", FilterOperator.EQ, oExpressionEntityData.PLANT_SEC),
						new Filter("PARAM8", FilterOperator.EQ, oExpressionEntityData.PLANT)
					],
					and: true
				});

				oModel.read("/ET_MII_DATA_LISTSet", {
					filters: [InputFilter],
					success: function (oData, response) {
						var vjson = JSON.parse(oData.results[0].RET_DATA);
						var data = vjson.Rowsets.Rowset[0];
						if (data.hasOwnProperty('Row')) {
							//testing :start
							if (data.Row[0].hasOwnProperty('ERRORMESSAGE')) {
								//error handling - some popup that takes it back to home page
								sap.m.MessageBox.error(data.Row[0].ERRORMESSAGE);
							} else if (data.Row[0].hasOwnProperty('Error') && data.Row[0].Error != "") {
								sap.m.MessageBox.error($(data.Row[0].Error).find("ERRORMESSAGE").text());
							} else
							//testing : end
							{
								if (that.isTagsFetched) {
									that.getView().getModel("EntityEditModel").setProperty("/EXPRESSION", expression);
								}
								that.onSubmitBtnPress();
							}
						} else {
							//error handling - some popup that takes it back to home page
							sap.m.MessageBox.error("Server returned incorrect response");
						}
					},
					error: function (oError) {
						sap.m.MessageBox.error(oError);
						console.log(oError);
						//error handling
					}
				});
				oModel.attachRequestSent(function () {
					that.byId("pageEdit").setBusy(true);
				});
				oModel.attachRequestCompleted(function () {
					that.byId("pageEdit").setBusy(false);
				});
			} else {
				this.onSubmitBtnPress();
			}
		},
		filterEditData: function (arr, val) {
			return arr.filter((el) => {
				return el[0] !== val[0];
			});
		},
		filterAndAddData: function (val) {
			this.totalValidatedTagsUsed = this.filterEditData(this.totalValidatedTagsUsed, val);
			this.totalValidatedTagsUsed.push(val);

		},
		calculateOriginalTagsUsed: function () {
			const regex = /TSLSTART([\s\S]*?)TSLEND/gm;
			let m;
			//new RegExp('TSLSTART([\s\S]*?)TSLEND', 'gi')

			while ((m = regex.exec(this.originalExpression)) !== null) {
				// This is necessary to avoid infinite loops with zero-width matches
				if (m.index === regex.lastIndex) {
					regex.lastIndex++;
				}
				var that = this;
				// The result can be accessed through the `m`-variable.
				m.forEach((match, groupIndex) => {
					//console.log(`Found match, group ${groupIndex}: ${match}`);
					if (match.includes(this.spaceDelimiter)) {
						match = that.replaceAll(match, this.spaceDelimiter, ' ');
					}
					that.totalValidatedTagsUsed.push([match]);
				});
			}
		},
		replaceAll: function (str, find, replace) {
			return str.replace(new RegExp(find, 'gi'), replace);
		},
		/*onfetchTagsEvent : function(){
			this.onfetchTags(false, this.getModel("EntityEditModel").getData());
		},*/
		onfetchTagsEvent: function () {
			var oView = this.getView(),
				oModel = this.getModel(),
				that = this,
				valid = false,
				//oTable = this.byId("tableEditor"),
				oTagsTable = this.byId("tableAvailableTags");
			var oExpressionEntity = this.getModel("EntityEditModel").getData();
			oExpressionEntity.TAG_FILTER = "*";

			//is it needed??
			/*var server = this.byId("editDataSource").getSelectedItem() === null ? null : this.byId("editDataSource").getSelectedItem()
				.getKey();
			oExpressionEntity.DATASOURCE = server;*/

			/*for (var property in oExpressionEntity) {
				if (oExpressionEntity[property] !== "") {
					valid = true;
				} else {
					valid = false;
					break;
				}
			}*/

			//TODO: validate the inputs
			valid = true;
			if (valid) {
				var InputFilter = new Filter({
					filters: [
						new Filter("PARAM0", FilterOperator.EQ, "getTag"),
						new Filter("PARAM1", FilterOperator.EQ, "*"),
						new Filter("PARAM2", FilterOperator.EQ, "*"),
						new Filter("PARAM3", FilterOperator.EQ, oExpressionEntity.TAG_FILTER),
						new Filter("PARAM4", FilterOperator.EQ, oExpressionEntity.DATASOURCE),
						new Filter("PARAM5", FilterOperator.EQ, oExpressionEntity.PLANT),
						new Filter("PARAM6", FilterOperator.EQ, oExpressionEntity.PLANT_SEC),
						new Filter("PARAM7", FilterOperator.EQ, "*"),
						new Filter("PARAM8", FilterOperator.EQ, "*")
					],
					and: true
				});
				if (oExpressionEntity.DATASOURCE === "SQL" || oExpressionEntity.DATASOURCE === "ORACLE") {
					/*this.byId("open").setVisible(true);
					this.byId("close").setVisible(true);*/
					this.byId("min").setVisible(true);
					this.byId("max").setVisible(true);
					this.byId("average").setVisible(true);
					this.byId("count").setVisible(true);
					this.byId("std").setVisible(true);
				} else {
					/*this.byId("open").setVisible(false);
					this.byId("close").setVisible(false);*/
					this.byId("min").setVisible(false);
					this.byId("max").setVisible(false);
					this.byId("average").setVisible(false);
					this.byId("count").setVisible(false);
					this.byId("std").setVisible(false);
				}
				oModel.read("/ET_MII_DATA_LISTSet", {
					filters: [InputFilter],
					success: function (oData, response) {
						that.isTagsFetched = true;
						var vjson = JSON.parse(oData.results[0].RET_DATA);
						var data = vjson.Rowsets.Rowset[0];
						if (data.hasOwnProperty('Row')) {
							if (data.Row[0].hasOwnProperty('ERRORMESSAGE')) {
								//error handling	
								sap.m.MessageBox.error(data.Row[0].ERRORMESSAGE);
							} else if (data.Row[0].hasOwnProperty('Error') && data.Row[0].Error != "") {
								//error handling
								var errMsg = $(data.Row[0].Error).find("ERRORMESSAGE").text();
								sap.m.MessageBox.error(errMsg);
							} else {
								oView.setModel(new JSONModel({
									"rows": data.Row
								}), "tags");
								that.getView().getModel("ui").setProperty("/plantSection", oExpressionEntity.PLANT_SEC);

								that.byId("GreyedOutExpressionlbl").setVisible(false);
								that.byId("GreyedOutTypeHere").setVisible(false);
								that.byId("grid").setVisible(true);
								that.byId("fetchNewTags").setText("Fetch New Tags");
								that.byId("fetchNewTags").setIcon("sap-icon://arrow-bottom");

							}
						} else {
							//error handling
							sap.m.MessageBox.error("Server failed to return tag data.");
						}
					},
					error: function (oError) {
						sap.m.MessageBox.error(oError);
						//console.log(oError);
						//error handling
					}
				});
				oModel.attachRequestSent(function () {
					oTagsTable.setBusy(true);
				});
				oModel.attachRequestCompleted(function () {
					oTagsTable.setBusy(false);
				});
			} else {
				sap.m.MessageBox.error("Please fill all mandatory fields");
			}
		},
		moveToEditorTextAreaEditScreen: function () {
			var oTableAvailableTags = this.byId("tableAvailableTags");
			var aContexts = oTableAvailableTags.getSelectedContexts();
			if (aContexts && aContexts.length) {
				var selectedTag = aContexts.map(function (oContext) {
					return oContext.getObject().NativeSource;
				});
				this.setTextArea(this.byId("TypeHere"), true, selectedTag);
				this.filterAndAddData(selectedTag);
			} else {
				MessageToast.show("Please select a tag");
			}
		},
		onOperationPressEditScreen: function (oEvent) {
			var btnId = oEvent.getSource().getId();
			var textArea = this.byId("TypeHere");
			this.setbuttons(btnId, textArea);
		}
	});

});