Date.prototype.toShortFormat = function() {
    var month_names =["Jan","Feb","Mar",
                      "Apr","May","Jun",
                      "Jul","Aug","Sep",
                      "Oct","Nov","Dec"];
    
    var day = this.getDate();
    var month_index = this.getMonth();
    var year = this.getFullYear();
    
    return "" + day + "-" + month_names[month_index] + "-" + year;
};

sap.ui.define([
	] , function () {
		"use strict";

		return {
			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
			convertMinsToHours : function(sValue){
				if(sValue){
					sValue = sValue/60;
				}
				return sValue;
			},
			getParticiple : function(sValue){
				if(sValue === "PENDING"){
					sValue = " with ";
				}else if(sValue === "APPROVED"){
					sValue = " by ";
				}else if(sValue === "DELETED"){
					sValue = " by ";
				}else {
					sValue = " "
				}
				return sValue;
			},
			expressionValue : function(sValue){
				if(sValue){
				var startDelimiter ="TSLSTART",
					endDelimiter="TSLEND",
					spaceDelimiter="TSL_SPACE_TSL";
					
				sValue = sValue.replace(new RegExp(spaceDelimiter, 'gi'), ' '); 
				sValue = sValue.replace(new RegExp(startDelimiter, 'gi'), '');
				sValue = sValue.replace(new RegExp(endDelimiter, 'gi'), '');
				}
				return sValue;
			},
			replaceAll: function(str, find, replace) {
		    	return str.replace(new RegExp(find, 'gi'), replace);
			},
			formatReasonText :  function(sValue){
				return "";
			},
			formatDescriptionBlank : function(sValue){
				if(sValue === null || sValue === ""){
					return "No Description";
				}
				return sValue;	
			},
			convertExpressionToAcceptableByMIISytem : function(expression){
				var x = this.totalValidatedTagsUsed;
				for(var i = 0; i < x.length; i++) {
					var tag = x[i][0];
					if(expression.includes(tag)){
						var newTag = tag;
						//if(datasourcecheck for space)
						newTag= this.replaceAll(tag, ' ', this.spaceDelimiter);
						
						expression= this.replaceAll(expression, tag, this.startDelimiter+newTag+this.endDelimiter);
					}
				}
				return expression;
			},
			
			formatDateStr : function(sValue){
				/*return new Date(sValue.replace(
				    /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/,
				    '$4:$5:$6 $2/$3/$1'
				));*/
				if(sValue){
				var dateString  = sValue;
				var year        = dateString.substring(0,4);
				var month       = dateString.substring(4,6);
				var day         = dateString.substring(6,8);
				var hh			= dateString.substring(9,11);
				var mm			= dateString.substring(11,13);
				var ss			= dateString.substring(13,15);
				return (new Date(year, month-1, day).toShortFormat())+" "+hh+":"+mm+":"+ss;
				}else{
					return sValue;
				}
				
			},
			convertStateStatus : function(sValue){
				if(sValue === "SAD"){
					sValue = "Draft";
				}else if(sValue === "PFA"){
					sValue = "Pending Approval";
				}else if(sValue === "DEL"){
					sValue = " for Delete";
				}else if(sValue === "CRT"){
					sValue = "Created";
				}else if(sValue === "EDT"){
					sValue = "Edited";
				}else if(sValue === "APR"){
					sValue = "Approved";
				}else if(sValue === "RET"){
					sValue = "Returned";
				}else if(sValue === "FI"){
					sValue = "Final";
				}else if(sValue === "DR"){
					sValue = "Draft";
				}else if(sValue === "PENDING"){
					sValue = "Pending Approval";
				}else if(sValue === "APPROVED"){
					sValue = "Approved";
				}else if(sValue === "FINAL"){
					sValue = " ";
				}
				return sValue;
			}

		};

	}
);