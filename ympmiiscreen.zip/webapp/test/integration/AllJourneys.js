jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"com/expression/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"com/expression/test/integration/pages/Worklist",
		"com/expression/test/integration/pages/Object",
		"com/expression/test/integration/pages/NotFound",
		"com/expression/test/integration/pages/Browser",
		"com/expression/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.expression.view."
	});

	sap.ui.require([
		"com/expression/test/integration/WorklistJourney",
		"com/expression/test/integration/ObjectJourney",
		"com/expression/test/integration/NavigationJourney",
		"com/expression/test/integration/NotFoundJourney",
		"com/expression/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});