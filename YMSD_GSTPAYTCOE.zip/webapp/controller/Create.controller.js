sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";

	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMSD_GST_PAY_SRV_01/");
	var binaryData = {};
	var fileType1 = " ";
	return Controller.extend("com.tatasteel.YMSD_GSTPAYTCOE.controller.Create", {

		onInit: function () {

		},

		goBack: function () {

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("TargetApprove", true);
			}
		},

		onCreate: function () {

			var amount = this.getView().byId("inputNumber").getValue();
			var COId = this.getView().byId("inputUserID").getValue();
			var tcoeRemarks = this.getView().byId("remarks").getValue();
			if (binaryData.value !== " ") {
				var attachment1 = binaryData.value;
			}
			
			if( this.getView().byId("inputNumber").getValue() === "" ){
				this.getView().byId("inputNumber").setValueState(sap.ui.core.ValueState.Error); 
				return false;
			}	
			else
				this.getView().byId("inputNumber").setValueState(sap.ui.core.ValueState.default); 
				
			if( this.getView().byId("inputUserID").getValue() === "" ){
				this.getView().byId("inputUserID").setValueState(sap.ui.core.ValueState.Error); 
				return false;
			}	
			else
				this.getView().byId("inputUserID").setValueState(sap.ui.core.ValueState.default); 	
				
			if(typeof binaryData.value === "undefined"){
				this.getView().byId("fileUploader").setValueState(sap.ui.core.ValueState.Error); 
				return false;
			}	
			

			var data = {
				"Snro": "000000",
				"Amount": parseInt(amount),
				"Coid": COId,
				// "TcoeEmail": tcoeEmail,
				"TcoeRemarks": tcoeRemarks,
				"Attachment1": attachment1,
				"Filetype1": fileType1 ? fileType1 : "",
				"RequestFrom": "TCOE"
			};
			
			var SimpleForm = this.getView().byId("SimpleFormChange354");
			SimpleForm.setBusy(true);   
			
			oModel.create("/GlobalSet", data, {
				success: function (oData,response) {
					console.log(response);
					SimpleForm.setBusy(false);
					sap.m.MessageToast.show("Request Submitted = " + response.data.Snro);
					
				},
				error: function(response){
					// console.log(response);
					SimpleForm.setBusy(false);
					sap.m.MessageToast.show(JSON.parse(response.responseText).error.message.value);	
					
				}
			});

		},

		handleValueChange: function (attachment) {
			var oFileUploader = this.getView().byId("fileUploader");
			var domRef = oFileUploader.getFocusDomRef();
			var file1 = domRef.files[0];
			fileType1 = file1.name.split(".")[1];
			// var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				var ImgContent5 = e.target.result;
				// that.getView().byId("myImage5").setSrc(ImgContent5);
				// return btoa(encodeURI(ImgContent5));
				// binaryData.value = encodeURI(ImgContent5);
				binaryData.value = btoa(encodeURI(ImgContent5));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 5.");
			};
			reader.readAsDataURL(file1);
		}

	});

});