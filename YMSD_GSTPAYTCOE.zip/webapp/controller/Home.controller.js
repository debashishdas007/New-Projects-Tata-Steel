sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Label",
	"sap/m/Dialog",
	"sap/m/TextArea",
	"sap/m/Button",
	"sap/ui/layout/HorizontalLayout",
	"sap/ui/layout/VerticalLayout",
	"sap/m/FlexBox"
	// "sap/tnt/InfoLabel"
], function (Controller, Label, Dialog, TextArea, Button, HorizontalLayout, VerticalLayout, FlexBox) {
	"use strict";
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMSD_GST_PAY_SRV_01/");
	var dialog = "";
	return Controller.extend("com.tatasteel.YMSD_GSTPAYTCOE.controller.Home", {

		onInit: function () {
			// =========================================== //
		},
		onBeforeRendering: function () {
			// var monthModel = new sap.ui.model.json.JSONModel();
			// monthModel.loadData(jQuery.sap.getModulePath("com.tatasteel.YMSD_GSTPAYTCOE.model", "/month.json"), null, false);
			// var currentMonth = new Date().getMonth() + 1;
			// currentMonth = currentMonth < 10 ? "0" + currentMonth : currentMonth;
			// var monthID = this.getView().byId("month");
			// monthModel.setData({
			// 	MonthsModel: monthModel.getData().Months,
			// 	currentMonth: currentMonth
			// });
			// monthID.setModel(monthModel);

			// this.onFetch(currentMonth, "0");

			this.onFetch(new Date().getFullYear().toString() + "-" + (new Date().getMonth()).toString() + "-" + new Date().getDate().toString(),
				new Date().getFullYear().toString() + "-" + (new Date().getMonth() + 1).toString() + "-" + new Date().getDate().toString(), "0");

		},
		onSearch: function () {
			// this.onFetch(this.getView().byId("month").getSelectedItem().getKey(), this.getView().byId("statusCombo").getSelectedItem().getKey());
			this.onFetch(this.getView().byId("dateFrom").getValue(), this.getView().byId("dateTo").getValue(), this.getView().byId(
				"statusCombo").getSelectedItem().getKey());
		},

		onFetch: function (dateFrom, dateTo, statusCombo) {
			var filters = [];
			var oFilters = new sap.ui.model.Filter("RequestFrom", sap.ui.model.FilterOperator.EQ, "TCOE");
			filters.push(oFilters);
			if (statusCombo !== "") {
				oFilters = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, statusCombo);
				filters.push(oFilters);
			}
			
			if(dateFrom === ""){
				this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.Error);
				return false;	
			}else{
				this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.Default);
			}
			if(dateTo === ""){
				dateTo = dateFrom;
			}
			
			oFilters = new sap.ui.model.Filter("Creationdate", sap.ui.model.FilterOperator.BT, dateFrom, dateTo);
			filters.push(oFilters);
			// oFilters = new sap.ui.model.Filter("Creationmonth", sap.ui.model.FilterOperator.EQ, month);
			// filters.push(oFilters);

			var oTable = this.getView().byId("crTable");
			oTable.setBusy(true);
			oModel.read("/GlobalSet", {
				filters: filters,
				success: function (oData, response) {
					var value = [];
					value = oData.results;
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData({
						oModelSet: value
					});
					var oTemplate = new sap.m.ColumnListItem({
						cells: [
							new sap.m.ObjectIdentifier({
								text: "{Snro}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Coid}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Copersnum}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Coname}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Coemail}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Amount}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeId}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoePersnum}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeName}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeEmail}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{CoRemarks}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeRemarks}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{CreationMonth}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{CreationDate}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Attachment1}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Attachment2}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								title: "{Status}",
								titleActive: false,
							}).bindProperty("title", {
								parts: [{
									path: "Status"
								}, {
									path: "Coname"
								}],
								formatter: function (Status, Coname) {
									if (Status == "0") {
										this.addStyleClass("statusRed");
										return "Pending at " + Coname;
									} else if (Status == "1") {
										this.addStyleClass("statusGreen");
										return "Completed";
									} else if (Status == "3") {
										return "Closed";
									}
								}
							}),
							new sap.m.ObjectIdentifier({
								text: "{Filetype1}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Filetype2}"
							}).addStyleClass("txtColor")
						]
					});
					oTable.setModel(oModel1);
					oTable.bindAggregation("items", {
						path: "/oModelSet",
						template: oTemplate
					});
					oTable.setBusy(false);
				},
				error: function (response) {
					oTable.setBusy(false);
					console.log(response);
				}
			});
		},
		goToCreate: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Create");
		},

		onView: function (event) {
			var oTable = this.getView().byId("crTable");
			this.selectedItems = oTable.getSelectedItems();
			if (this.selectedItems.length === 0) {
				return false;
			}

			var that = this;
			if (dialog != "") {
				dialog.open();
				return false;
			}
			//dialog = new Dialog("remarksDialog", {
			// dialog = new sap.m.Dialog({
			// 	title: "Remarks",
			// 	type: "Message",
			// 	content: [
			// 		new HorizontalLayout({
			// 			content: [
			// 				new VerticalLayout({
			// 					width: "100%",
			// 					content: [
			// 						new sap.m.Label({
			// 							text: "Download:"
			// 						})
			// 					]
			// 				}),
			// 				new VerticalLayout({
			// 					content: [
			// 						new sap.m.Button({
			// 							type: "Default",
			// 							//icon: that.selectedItems[0].getCells()[14].getText() === "pdf" ? "sap-icon://pdf-attachment" : "sap-icon://excel-attachment",
			// 							width: "10%",
			// 							press: function () {
			// 								that.onFileDownload(that);
			// 							}
			// 						})
			// 					]
			// 				})
			// 			]
			// 		}),
			// 		new TextArea("confirmDialogTextarea", {
			// 			width: "100%",
			// 			placeholder: "Add your Remarks",
			// 			liveChange: function (oEvent) {
			// 				var sText = oEvent.getParameter("value");
			// 				var parent = oEvent.getSource().getParent();
			// 				parent.getBeginButton().setEnabled(sText.length > 0);
			// 			}
			// 		})
			// 	],
			// 	beginButton: new Button({
			// 		text: "Submit",
			// 		enabled: false,
			// 		//type: event.getSource().getType(),
			// 		press: function () {
			// 			that.onCRApprove(that);
			// 			//dialog.close();
			// 		}
			// 	}),
			// 	endButton: new Button({
			// 		text: "Cancel",
			// 		press: function () {
			// 			dialog.close();
			// 			dialog.destroy();
			// 			dialog = "";
			// 		}
			// 	})
			// });

			dialog = new sap.m.Dialog({
				title: "Attachments",
				type: "Standard",
				content: [
					new sap.m.Panel({
						expanded: true,
						content: [
							new FlexBox({
								height: "100px",
								alignContent: "Center",
								alignItems: "Center",
								items: [
									new sap.m.Button({
										type: "Default",
										icon: that.selectedItems[0].getCells()[17].getText() === "pdf" ? "sap-icon://pdf-attachment" : "sap-icon://excel-attachment",
										press: function () {
											that.onFileDownload(that, 1);
										}
									}).addStyleClass("sapUiLargeMarginBegin"),
									new sap.m.Button({
										type: "Default",
										icon: that.selectedItems[0].getCells()[18].getText() === "pdf" ? "sap-icon://pdf-attachment" : "sap-icon://excel-attachment",
										class: "sapUiLargeMarginBegin",
										press: function () {
											that.onFileDownload(that, 2);
										}
									}).addStyleClass("sapUiLargeMarginBegin")
								]
							}).addStyleClass("dialogFlexBox"),
							new HorizontalLayout({
								content: [
									new VerticalLayout({
										width: "100%",
										content: [
											new sap.m.Label({
												text: "Attachment By TCOE"
											})
										]
									}).addStyleClass("sapUiLargeMarginBegin"),
									new VerticalLayout({
										width: "100%",
										content: [
											new sap.m.Label({
												text: "Attachment By CO"
											})
										]
									}).addStyleClass("sapUiSmallMarginBegin")
								]
							})
						]
					})

				],
				beginButton: new Button({
					text: "Ok",
					enabled: true,
					//type: event.getSource().getType(),
					press: function () {
						//that.onCRApprove(that);
						//dialog.close();
						dialog.close();
						dialog.destroy();
						dialog = "";
					}
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						dialog.close();
						dialog.destroy();
						dialog = "";
					}
				})
			});

			dialog.open();
		},

		onFileDownload: function (data, attachmentNo) {
			// console.log(selectedItem);
			if (data.selectedItems[0].getCells()[0].getText().trim() !== " ") {
				// oModel.read("/FileSet('" + data.selectedItems[0].getCells()[0].getText().trim() + "')", {
				oModel.read("/FileSet(Snro='" + data.selectedItems[0].getCells()[0].getText().trim() + "',AttachmentNo='" + attachmentNo + "')", {
					// filters: filters,
					success: function (oData, response) {
						var value = [];
						value = response.data;
						var link = document.createElement("a");
						var attachementType = attachmentNo === 1 ? value.Attachment1 : value.Attachment2;
						link.href = atob(attachementType);
						var fileName = " ";
						if (attachmentNo === 1)
							fileName = data.selectedItems[0].getCells()[6].getText().trim() + "_" + value.Snro + "." + value.Filetype1;
						else {
							fileName = data.selectedItems[0].getCells()[1].getText().trim() + "_" + value.Snro + "." + value.Filetype2;
							if (value.Attachment2 == "") {
								sap.m.MessageToast.show("No File Uploaded by Cash Office");
								return false;
							}
						}

						link.download = fileName;
						link.click();
					}
				});
			}
		},

		onCRApprove: function (data) {
			var that = this;
			if (data.selectedItems[0].getCells()[0].getText().trim() !== " ") {

				if (dialog === "" || dialog.getContent().length == 0) {
					dialog.destroy();
					dialog = "";
					return false;
				}

				var updatedata = {
					"Snro": data.selectedItems[0].getCells()[0].getText(),
					"TcoeEmail": data.selectedItems[0].getCells()[9].getText(),
					"Crname": data.selectedItems[0].getCells()[3].getText(),
					"CrRemarks": dialog.getContent()[1].getValue(),
					"RequestFrom": "C&R",
					Status: 3
				};

				dialog.destroy();
				dialog = "";

				var oModel2 = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMSD_GST_PAY_SRV_01/");
				oModel2.sDefaultUpdateMethod = "PUT";

				oModel2.update("/GlobalSet('" + data.selectedItems[0].getCells()[0].getText() + "')", updatedata, {
					success: function (oData, response) {
						console.log(response);
						sap.m.MessageToast.show("Successfully Submitted");
						that.onInit();
					},
					error: function (response) {
						console.log(response);
						sap.m.MessageToast.show("Error");
					}
				});

			}
		}

	});

});