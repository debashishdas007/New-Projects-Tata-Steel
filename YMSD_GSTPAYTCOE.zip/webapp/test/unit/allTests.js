sap.ui.define([
	"com/tatasteel/YMSD_GSTPAYTCOE/test/unit/controller/App.controller"
], function () {
	"use strict";
});