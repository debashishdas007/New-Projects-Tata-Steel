/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"com/tatasteel/YMSD_GSTPAYTCOE/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/tatasteel/YMSD_GSTPAYTCOE/test/integration/pages/App",
	"com/tatasteel/YMSD_GSTPAYTCOE/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.tatasteel.YMSD_GSTPAYTCOE.view.",
		autoWait: true
	});
});