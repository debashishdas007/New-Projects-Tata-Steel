sap.ui.define([
	"com/tatasteel/YMSD_GSTPAYCO/test/unit/controller/App.controller"
], function () {
	"use strict";
});