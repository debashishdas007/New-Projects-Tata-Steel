sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";

	var oRouter;
	var binaryData = {};
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMSD_GST_PAY_SRV_01/");
	var fileType = " ";
	return Controller.extend("com.tatasteel.YMSD_GSTPAYCO.controller.Details", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.tatasteel.YMSD_GSTPAYCO.view.Details
		 */
		onInit: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Details").attachPatternMatched(this._onObjectMatched, this);
			
			
		},

		_onObjectMatched: function (oEvent) {

			var Snro = oEvent.getParameter("arguments").Snro.trim();
			if (Snro !== " ") {
				var crModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().getModel("crModel").getData());
				this.getView().byId("SimpleFormChange354").setModel(crModel, "formModel");
			}
			if (sap.ui.getCore().getModel("crModel").getData().Status === "Completed") {
				this.getView().byId("coApproval").setEnabled(false);
				this.getView().byId("cashOfficeLabel").setVisible(true);
				this.getView().byId("cashOfficeFileDownload").setVisible(true);

			} else {
				this.getView().byId("coApproval").setEnabled(true);
			}
			// var cashoffierFile = new sap.m.Label({
			// 	text: "Download Cash Officer file"
			// }).addStyleClass("headerBold");
			// this.getView().byId("SimpleFormChange354").addDependent(cashoffierFile);

		},
		
		onTcoeFileDownload: function(){
			this.onFileDownload("1");
		},
		
		onCoFileDownload: function(){
			this.onFileDownload("2");
		},
		// FileSet(Snro='00001',AttachmentNo='2')
		onFileDownload: function (attachmentNo) {
			if (sap.ui.getCore().getModel("crModel") !== null) {
				// oModel.read("/FileSet('"+ sap.ui.getCore().getModel("crModel").getData().Snro +"')", {
				
				oModel.read("/FileSet(Snro='" + sap.ui.getCore().getModel("crModel").getData().Snro + "',AttachmentNo='"+attachmentNo+"')", {
					success: function (oData, response) {
						var value = [];
						value = response.data;
						var link = document.createElement("a");
						if (attachmentNo === "1"){
							link.href = atob(value.Attachment1);
							fileType = value.Filetype1;
						}
						else if(attachmentNo === "2"){
							link.href = atob(value.Attachment2);
							fileType = value.Filetype2;
						}
							
						var fileName = sap.ui.getCore().getModel("crModel").getData().TcoeId + "_" + value.Snro + "." + fileType;
						link.download = fileName;
						link.click();
					}
				});

			}
		},

		goBack: function () {

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("COPerson", true);
			}
		},

		cosubmit: function () {
			var coRemarks = this.getView().byId("coRemarks").getValue();
			if (this.getView().byId("coRemarks").getValue() === "") {
				this.getView().byId("coRemarks").setValueState(sap.ui.core.ValueState.Error);
				return false;
			}

			if (typeof binaryData.value !== "undefined") {
				var attachment = binaryData.value;
			}

			var data = {
				"Snro": sap.ui.getCore().getModel("crModel").getData().Snro,
				"Coemail": sap.ui.getCore().getModel("crModel").getData().Cremail,
				"TcoeEmail": sap.ui.getCore().getModel("crModel").getData().TcoeEmail,
				"CoRemarks": coRemarks,
				"Attachment2": attachment,
				"RequestFrom": "CO",
				"Filetype2": fileType ? fileType : " "
			};

			oModel.create("/GlobalSet", data, {
				success: function (response) {
					//console.log(response);
					sap.m.MessageToast.show("Successfully Submitted");
				},
				error: function (response) {
					//console.log(response);
					sap.m.MessageToast.show(JSON.parse(response.responseText).error.message.value);
				}
			});

		},

		handleValueChange: function (attachment) {
			var oFileUploader = this.getView().byId("fileUploader");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			fileType = file.name.split(".")[1];
			// var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				var fileContent = e.target.result;
				binaryData.value = btoa(encodeURI(fileContent));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading file.");
			};
			reader.readAsDataURL(file);
		}

	});

});