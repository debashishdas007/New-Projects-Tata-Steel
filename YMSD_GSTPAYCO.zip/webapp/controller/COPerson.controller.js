sap.ui.define([
	"sap/ui/core/mvc/Controller"
	// "sap/tnt/InfoLabel"
], function (Controller) {
	"use strict";

	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMSD_GST_PAY_SRV_01/");
	return Controller.extend("com.tatasteel.YMSD_GSTPAYCO.controller.COPerson", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.tatasteel.YMSD_GSTPAYCO.view.COPerson
		 */

		onInit: function () {
			console.log("OnInit");
			// =========================================== //

		},
		onBeforeRendering: function(){
			console.log("OnBefore Rendering");
			this.onFetch(new Date().getFullYear().toString()+"-"+(new Date().getMonth()).toString()+"-"+new Date().getDate().toString(),new Date().getFullYear().toString() +"-"+ (new Date().getMonth()+1).toString()+"-"+new Date().getDate().toString() ,"0");
		},
		onAfterRendering: function(){
			console.log("OnAfter Rendering");
		},
		
		onSearch: function(){
			// this.onFetch(this.getView().byId("month").getSelectedItem().getKey(), this.getView().byId("statusCombo").getSelectedItem().getKey());
			this.onFetch( this.getView().byId("dateFrom").getValue(), this.getView().byId("dateTo").getValue() ,this.getView().byId("statusCombo").getSelectedItem().getKey());
		},
		
		onFetch: function (dateFrom,dateTo,statusCombo) {
			var filters = [];
			var oFilters = new sap.ui.model.Filter("RequestFrom", sap.ui.model.FilterOperator.EQ, "CO");
			filters.push(oFilters);
			if (statusCombo !== "") {
				oFilters = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, statusCombo);
				filters.push(oFilters);
			}
			
			if(dateFrom === ""){
				this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.Error);
				return false;	
			}else{
				this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.Default);
			}
			if(dateTo === ""){
				dateTo = dateFrom;
			}
			
			
			oFilters = new sap.ui.model.Filter("Creationdate", sap.ui.model.FilterOperator.BT, dateFrom, dateTo);
			filters.push(oFilters);
			
			// oFilters = new sap.ui.model.Filter("Creationmonth", sap.ui.model.FilterOperator.EQ, month);
			// filters.push(oFilters);
			

			var oTable = this.getView().byId("tcoeTable");
			oTable.setBusy(true);
			oModel.read("/GlobalSet", {
				filters: filters,
				success: function (oData, response) {
					var value = [];
					value = oData.results;
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData({
						oModelSet: value
					});
					var oTemplate = new sap.m.ColumnListItem({
						cells: [
							new sap.m.ObjectIdentifier({
								text: "{Snro}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Coid}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Copersnum}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Coname}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Coemail}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Amount}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeId}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoePersnum}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeName}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeEmail}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{TcoeRemarks}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{CoRemarks}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Creationmonth}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Creationdate}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Attachment1}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Attachment2}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								title: "{Status}",
								titleActive: false,
							}).bindProperty("title", {
								parts: [{
									path: "Status"
								}, {
									path: "Coname"
								}],
								formatter: function (Status, Coname) {
									if (Status == "0") {
										this.addStyleClass("statusRed");
										return "Pending";
									} else if (Status == "1") {
										this.addStyleClass("statusGreen");
										return "Completed";
									} else if (Status == "3") {
										return "Closed";
									}
								}
							}),
							new sap.m.ObjectIdentifier({
								text: "{Filetype1}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{Filetype2}"
							}).addStyleClass("txtColor")
						]
					});
					oTable.setModel(oModel1);
					oTable.bindAggregation("items", {
						path: "/oModelSet",
						template: oTemplate
					});
					oTable.setBusy(false);
				},
				error: function (response) {
						oTable.setBusy(false);
						console.log(response);
				}
			});
		},
		onView: function () {

			var oTable = this.getView().byId("tcoeTable");
			var selectedItems = oTable.getSelectedItems();

			var Snro = selectedItems[0].getCells()[0].getText();
			var data = {
				Snro: selectedItems[0].getCells()[0].getText(),
				Crid: selectedItems[0].getCells()[1].getText(),
				CrPersnum: selectedItems[0].getCells()[2].getText(),
				Crname: selectedItems[0].getCells()[3].getText(),
				Cremail: selectedItems[0].getCells()[4].getText(),
				Amount: selectedItems[0].getCells()[5].getText(),
				TcoeId: selectedItems[0].getCells()[6].getText(),
				TcoePersnum: selectedItems[0].getCells()[7].getText(),
				TcoeName: selectedItems[0].getCells()[8].getText(),
				TcoeEmail: selectedItems[0].getCells()[9].getText(),
				CrRemarks: selectedItems[0].getCells()[11].getText(),
				TcoeRemarks: selectedItems[0].getCells()[10].getText(),
				Attachment1: selectedItems[0].getCells()[14].getText(),
				Attachment2: selectedItems[0].getCells()[15].getText(),
				Status: selectedItems[0].getCells()[16].getTitle(),
				Filetype1: selectedItems[0].getCells()[17].getText(),
				Filetype2: selectedItems[0].getCells()[18].getText()
			};

			var dataModel = new sap.ui.model.json.JSONModel(data);
			sap.ui.getCore().setModel(dataModel, "crModel");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("Details");
			oRouter.navTo("Details", {
				Snro: Snro
			});
		}

	});

});